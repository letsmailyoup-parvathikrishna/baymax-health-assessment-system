# Baymax Health Advisor API Documentation

## Overview

The Baymax Health Advisor API provides AI-powered health symptom analysis using a hybrid approach combining:
- Artificial Neural Networks (ANNs)
- Medical Rule Engine
- LLM-based validation and advice

## Endpoints

### POST /api/advice

Analyze symptoms and receive a comprehensive health report.

#### Request Body

```json
{
  "symptoms": ["fever", "cough", "body_ache"],
  "severity": {
    "fever": 7,
    "cough": 6,
    "body_ache": 7
  },
  "duration": 24,
  "age": 35,
  "gender": "male",
  "existingConditions": ["diabetes"]
}
```

#### Request Fields

- `symptoms` (required): Array of symptom strings
- `severity` (required): Object mapping symptom names to severity (0-10)
- `duration` (required): Number of hours since symptoms started
- `age` (optional): Patient age
- `gender` (optional): Patient gender
- `existingConditions` (optional): Array of existing medical conditions

#### Response

```json
{
  "meta": {
    "confidence": 85,
    "warnings": ["High fever detected"]
  },
  "ann": {
    "diseaseProbabilities": {
      "flu": 0.65,
      "cold": 0.20,
      "covid": 0.10,
      "allergy": 0.02,
      "migraine": 0.01,
      "stomach_infection": 0.01,
      "uti": 0.005,
      "dehydration": 0.005,
      "anxiety": 0.0,
      "food_poisoning": 0.0
    },
    "severity": 70,
    "riskEngine": {
      "riskLevel": "medium",
      "emergencyScore": 45,
      "progressionScore": 35
    }
  },
  "ruleEngine": {
    "corrected": { ... },
    "ruleWarnings": []
  },
  "validation": {
    "llmChecks": {
      "logical": true,
      "issues": [],
      "contradictions": [],
      "impossible": []
    },
    "consistencyChecks": {
      "consistencyScore": 0.85,
      "warnings": [],
      "isManipulated": false
    }
  },
  "finalAdvice": "Hello! I'm Baymax, your personal healthcare companion..."
}
```

### GET /api/health

Health check endpoint to verify API status.

#### Response

```json
{
  "status": "healthy",
  "service": "Baymax Health Advisor",
  "timestamp": "2024-01-01T12:00:00.000Z"
}
```

## Supported Symptoms

The system recognizes the following symptoms:

- `fever`, `cough`, `sore_throat`, `runny_nose`, `congestion`
- `headache`, `nausea`, `vomiting`, `diarrhea`, `fatigue`
- `body_ache`, `chills`, `sweating`, `dizziness`, `chest_pain`
- `shortness_of_breath`, `wheezing`, `sneezing`, `itchy_eyes`
- `stomach_pain`, `abdominal_cramps`, `burning_urination`
- `frequent_urination`, `back_pain`, `joint_pain`, `rash`
- `sore_muscles`, `loss_of_appetite`, `thirst`, `dry_mouth`
- `confusion`, `irritability`, `anxiety`, `rapid_heartbeat`

## Disease Categories

The system predicts probabilities for:

1. `flu` - Influenza
2. `cold` - Common cold
3. `covid` - COVID-19
4. `allergy` - Allergic reaction
5. `migraine` - Migraine headache
6. `stomach_infection` - Stomach infection
7. `uti` - Urinary tract infection
8. `dehydration` - Dehydration
9. `anxiety` - Anxiety disorder
10. `food_poisoning` - Food poisoning

## Risk Levels

- `low`: Symptoms are mild, self-care recommended
- `medium`: Moderate symptoms, monitor closely, consider medical consultation
- `high`: Severe symptoms, seek medical attention

## Example Usage

### cURL

```bash
curl -X POST http://localhost:3000/api/advice \
  -H "Content-Type: application/json" \
  -d '{
    "symptoms": ["fever", "cough", "body_ache"],
    "severity": {
      "fever": 7,
      "cough": 6,
      "body_ache": 7
    },
    "duration": 24,
    "age": 35
  }'
```

### JavaScript/TypeScript

```typescript
const response = await fetch('http://localhost:3000/api/advice', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    symptoms: ['fever', 'cough', 'body_ache'],
    severity: { fever: 7, cough: 6, body_ache: 7 },
    duration: 24,
    age: 35
  })
});

const report = await response.json();
console.log(report.finalAdvice);
```

## Environment Variables

- `OPENAI_API_KEY`: OpenAI API key for LLM features (optional, uses mock if not set)
- `PORT`: Server port (default: 3000)

## Notes

- The system uses mock LLM responses if `OPENAI_API_KEY` is not set
- All models are initialized on first request (may take a few seconds)
- The system is designed for informational purposes and should not replace professional medical advice

