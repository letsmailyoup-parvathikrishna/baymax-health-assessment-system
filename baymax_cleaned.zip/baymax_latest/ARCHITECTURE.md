# Baymax Health Advisor - Architecture Documentation

## System Overview

The Baymax Health Advisor backend is a production-ready AI system that combines multiple AI and rule-based approaches to analyze health symptoms and provide medical advice.

## Architecture Components

### 1. Symptom Consistency Checker ANN (`src/ann/consistencyModel.ts`)

**Purpose**: Detects wrong inputs, contradictory symptoms, and unrealistic patterns.

**Architecture**:
- Input: 36-dimensional feature vector (symptoms + metadata)
- Network: 3-layer feedforward network (64 → 32 → 3 neurons)
- Output: [consistency_score, manipulation_score, warning_score]
- Activation: ReLU (hidden), Sigmoid (output)

**Features**:
- Detects logical symptom combinations
- Identifies impossible symptoms
- Flags contradictory symptoms
- Validates severity patterns

### 2. Symptom → Disease Probability ANN (`src/ann/diseaseModel.ts`)

**Purpose**: Main classifier that predicts disease probabilities.

**Architecture**:
- Input: 36-dimensional feature vector
- Network: 4-layer deep network (128 → 64 → 32 → 10 neurons)
- Output: 10 disease probabilities (softmax)
- Activation: ReLU (hidden), Softmax (output)

**Disease Classes**:
1. flu, cold, covid, allergy, migraine
2. stomach_infection, uti, dehydration, anxiety, food_poisoning

**Output**:
- Disease probabilities (normalized to sum to 1)
- Severity score (0-100)
- Confidence score (0-100)

### 3. Risk Engine ANN (`src/ann/riskModel.ts`)

**Purpose**: Predicts worsening likelihood, urgent-care risk, and progression.

**Architecture**:
- Input: 36-dimensional feature vector
- Network: 4-layer network (96 → 48 → 24 → 5 neurons)
- Output: [worsening, urgent_care, dehydration, fever_onset, infection_spread]
- Activation: ReLU (hidden), Sigmoid (output)

**Output**:
- Risk level: "low" | "medium" | "high"
- Emergency score (0-100)
- Progression score (0-100)

### 4. Medical Rule Engine (`src/rules/`)

**Purpose**: Applies medical knowledge to correct ANN outputs.

**Components**:
- `symptomRules.ts`: Defines medical rules
- `ruleEngine.ts`: Applies rules and caps impossible predictions

**Rules Include**:
- Respiratory symptom combinations
- Fever + body ache → flu
- Stomach symptoms → GI infections
- UTI symptom patterns
- Dehydration indicators
- Allergy patterns
- Contradiction detection

### 5. LLM Validator Layer (`src/llm/`)

**Purpose**: Validates symptoms using LLM and generates natural language advice.

**Components**:
- `validator.ts`: Validates symptom consistency with LLM
- `adviceGenerator.ts`: Generates friendly health advice

**Features**:
- OpenAI GPT-4 integration (with mock fallback)
- JSON-structured validation
- Natural language advice generation
- Medical consistency checking

### 6. Hybrid Pipeline (`src/pipeline/runAnalysis.ts`)

**Purpose**: Orchestrates all components into a unified analysis pipeline.

**Pipeline Flow**:
1. LLM Symptom Validator
2. Consistency Checker ANN
3. Disease Prediction ANN
4. Medical Rule Engine
5. Risk Engine ANN
6. Merge & Calculate Meta Information
7. Generate Natural Language Advice

**Output**: `BaymaxHealthReport` with complete analysis

## Data Flow

```
User Input (Symptoms)
    ↓
LLM Validator → [logical, issues, contradictions]
    ↓
Consistency ANN → [consistencyScore, warnings, isManipulated]
    ↓
Disease ANN → [probabilities, severity, confidence]
    ↓
Rule Engine → [corrected probabilities, ruleWarnings]
    ↓
Risk ANN → [riskLevel, emergencyScore, progressionScore]
    ↓
Merge & Calculate Meta
    ↓
LLM Advice Generator → [natural language advice]
    ↓
Final Report
```

## File Structure

```
src/
├── ann/                    # Neural network models
│   ├── consistencyModel.ts
│   ├── diseaseModel.ts
│   ├── riskModel.ts
│   ├── preprocess.ts
│   └── train/             # Training scripts
│       ├── trainAll.ts
│       ├── trainConsistency.ts
│       ├── trainDisease.ts
│       ├── trainRisk.ts
│       └── datasets/
├── rules/                  # Medical rule engine
│   ├── ruleEngine.ts
│   └── symptomRules.ts
├── llm/                    # LLM integration
│   ├── validator.ts
│   └── adviceGenerator.ts
├── pipeline/               # Main pipeline
│   └── runAnalysis.ts
├── routes/                 # API routes
│   └── advice.ts
├── types/                  # TypeScript types
│   └── index.ts
├── examples/               # Example usage
│   └── example.ts
└── index.ts                # Express server
```

## Technology Stack

- **Runtime**: Node.js
- **Language**: TypeScript
- **ML Framework**: TensorFlow.js (@tensorflow/tfjs-node)
- **Web Framework**: Express.js
- **LLM**: OpenAI GPT-4 (with mock fallback)
- **Environment**: dotenv

## Model Initialization

All ANN models are lazy-loaded and initialized on first use. The pipeline includes an `initialize()` method to warm up all models.

## Training

Models can be trained using:
```bash
npm run train
```

Training scripts use synthetic data by default. Replace with real medical datasets for production.

## API Integration

The system exposes a REST API:
- `POST /api/advice` - Main analysis endpoint
- `GET /api/health` - Health check

## Error Handling

- All components include error handling
- LLM failures fall back to mock responses
- Model initialization errors are caught and reported
- API errors return appropriate HTTP status codes

## Performance Considerations

- Models are initialized once and reused
- TensorFlow.js operations are optimized for Node.js
- LLM calls are optional (mock fallback available)
- All tensor operations properly dispose of memory

## Future Enhancements

- Model persistence (save/load trained models)
- Real medical dataset integration
- Model fine-tuning capabilities
- Caching for common symptom patterns
- Batch processing support
- WebSocket support for real-time analysis

