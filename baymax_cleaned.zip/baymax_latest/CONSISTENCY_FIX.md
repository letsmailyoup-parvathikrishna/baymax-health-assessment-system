# Consistency Checker Fix - Improved Manipulation Detection

## Problem Identified

The consistency checker was not properly detecting manipulation when users selected too many symptoms. For example:
- User selected almost all 50 symptoms
- System showed: Manipulation Detected: ✅ No (should be Yes)
- Consistency Score: 46.6% (should be much lower)
- LLM Validation: Logical: ✅ Yes (should be No)

## Fixes Implemented

### 1. Enhanced Rule-Based Detection (`src/ann/models/consistencyChecker.ts`)

**Added Strong Detection Rules:**

- ✅ **Too Many Symptoms**: 
  - >25 symptoms → Manipulated (with warning)
  - >20 symptoms → Manipulated (with warning)
  - >15 symptoms → Warning

- ✅ **Symptom System Diversity Check**:
  - If 4+ different body systems affected with >12 symptoms → Manipulated
  - Systems: Respiratory, GI, Urinary, Neurological, Psychological, Cardiac

- ✅ **Lower Manipulation Threshold**:
  - Changed from 0.7 to 0.5 (more sensitive)
  - Multiple warning indicators trigger manipulation flag

- ✅ **Severity Pattern Checks**:
  - All symptoms at max severity (9-10) → Manipulated
  - Unrealistic distribution (high max, low avg) → Manipulated

### 2. Improved Training Data (`src/ann/train/datasetLoader.ts`)

**Better Labeling:**
- Realistic (3-12 symptoms): Consistency 0.7-1.0, Manipulation 0.05-0.15
- Suspicious (13-20 symptoms): Consistency 0.4-0.7, Manipulation 0.2-0.9
- Manipulated (>20 symptoms): Consistency 0.0-0.4, Manipulation 0.9-1.0

**Added System Diversity Detection:**
- Checks for symptoms across multiple body systems
- Penalizes unrealistic combinations

### 3. Enhanced Dataset Generation (`src/dataset/generateMedicalDataset.ts`)

**Added Manipulation Examples:**
- 200 samples with 25-39 symptoms (labeled as 'manipulated')
- 150 samples with 4+ body systems affected (labeled as 'inconsistent')
- These examples train the model to recognize manipulation patterns

### 4. Improved LLM Validator (`src/llm/validator.ts`)

**Enhanced Mock Validation:**
- Detects >25 symptoms as "impossible"
- Detects >20 symptoms as "issues"
- Checks for 5+ body systems as "impossible"
- Better logical determination

## How to Retrain the Model

### Option 1: Retrain Only Consistency Model (Recommended)

```bash
npm run retrain-consistency
```

This will:
1. Regenerate dataset with manipulation examples
2. Retrain consistency model with improved data
3. Test manipulation detection
4. Save updated model

### Option 2: Retrain All Models

```bash
npm run generate-dataset  # Regenerate with manipulation examples
npm run train              # Retrain all models
```

## Expected Behavior After Retraining

### Test Case: User selects 40+ symptoms

**Before Fix:**
- Manipulation Detected: ❌ No
- Consistency Score: ~46%
- LLM Logical: ✅ Yes

**After Fix:**
- Manipulation Detected: ✅ **Yes**
- Consistency Score: **<30%**
- LLM Logical: ❌ **No**
- Warnings: "Too many symptoms selected (40). This is medically unrealistic."

### Test Case: User selects 15 symptoms from 4+ body systems

**After Fix:**
- Manipulation Detected: ✅ **Yes** (if >12 symptoms)
- Warning: "Symptoms affecting 4 different body systems simultaneously is highly unusual"

## Detection Thresholds

| Symptom Count | Consistency Score | Manipulation Score | Is Manipulated |
|---------------|-------------------|---------------------|----------------|
| ≤10 | 0.7-1.0 | 0.05-0.15 | ❌ No |
| 11-15 | 0.4-0.7 | 0.2-0.6 | ⚠️ Warning |
| 16-20 | 0.4-0.7 | 0.6-0.9 | ⚠️ Warning |
| 21-25 | 0.0-0.4 | 0.9-1.0 | ✅ Yes |
| >25 | 0.0-0.3 | 0.9-1.0 | ✅ Yes |

## Verification

After retraining, test with:

```bash
# Test with many symptoms
curl -X POST http://localhost:3000/api/advice \
  -H "Content-Type: application/json" \
  -d '{
    "symptoms": ["fever", "cough", "runny_nose", "nausea", "vomiting", "diarrhea", "headache", "dizziness", "anxiety", "chest_pain", "burning_urination", "rash", "fatigue", "body_ache", "chills", "sweating", "irritability", "rapid_heartbeat", "shortness_of_breath", "stomach_pain", "back_pain", "joint_pain", "confusion", "trembling", "restlessness"],
    "severity": {
      "fever": 8, "cough": 7, "runny_nose": 6, "nausea": 8, "vomiting": 7,
      "diarrhea": 8, "headache": 9, "dizziness": 7, "anxiety": 8, "chest_pain": 9,
      "burning_urination": 8, "rash": 7, "fatigue": 8, "body_ache": 9, "chills": 8,
      "sweating": 7, "irritability": 8, "rapid_heartbeat": 9, "shortness_of_breath": 9,
      "stomach_pain": 8, "back_pain": 7, "joint_pain": 8, "confusion": 8,
      "trembling": 7, "restlessness": 8
    },
    "duration": 24,
    "age": 35
  }'
```

**Expected Result:**
- `manipulationDetected: true`
- `consistencyScore: <0.3`
- `warnings: ["Too many symptoms selected (25)...", "Symptoms affecting 5 different body systems..."]`
- `llmChecks.logical: false`

## Summary

✅ **Fixed**: Rule-based detection now properly flags >20 symptoms  
✅ **Fixed**: Training data includes manipulation examples  
✅ **Fixed**: Lower manipulation threshold (0.5 instead of 0.7)  
✅ **Fixed**: System diversity detection  
✅ **Fixed**: LLM validator detects too many symptoms  
✅ **Added**: Retraining script for consistency model  

**Next Step**: Run `npm run retrain-consistency` to train the improved model!

