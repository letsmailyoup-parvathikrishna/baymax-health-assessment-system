# Dataset Documentation

## Overview

The Baymax Health Advisor uses medically accurate datasets for training ANN models.

## Dataset Generation

### Generate New Dataset

```bash
npm run generate-dataset
```

This creates:
- `src/ann/train/datasets/medical_dataset_3000.csv` - CSV format
- `src/ann/train/datasets/medical_dataset_3000.json` - JSON format

### Dataset Size

- **Total Samples**: 3000
- **Training Split**: 80% (2400 samples)
- **Test Split**: 20% (600 samples)

## Dataset Structure

### CSV Format

**Columns (45 total):**
1. **Symptoms (39 columns)**: Binary (0/1) indicators
   - fever, cough, runny_nose, sore_throat, headache, body_ache, fatigue
   - loss_of_smell, loss_of_taste, nausea, vomiting, diarrhea, stomach_cramps
   - chest_pain, difficulty_breathing, dizziness, rapid_heartbeat, chills
   - rash, itchy_skin, joint_pain, burning_urination, frequent_urination
   - lower_abdominal_pain, bloating, gas, dehydration_signs, dry_mouth
   - sensitivity_to_light, anxiety, restlessness, trembling, sweating
   - irritability, trouble_sleeping, appetite_loss, weight_loss, weight_gain
   - throat_itchiness

2. **Metadata (5 columns)**:
   - age: Patient age (5-100)
   - gender: 0 (male) or 1 (female)
   - stress_level: 0.0-1.0
   - sleep_hours: Hours of sleep (3-10)
   - water_intake: Liters per day (0.5-4.0)

3. **Label (1 column)**:
   - Disease classification: flu, common_cold, covid, allergy, migraine, stomach_infection, urinary_infection, dehydration, anxiety_attack, food_poisoning

## Disease Distribution

The generated dataset includes:

| Disease | Samples | Key Symptoms |
|---------|---------|--------------|
| Flu | 400 | fever, cough, body_ache, chills |
| Common Cold | 400 | runny_nose, sore_throat, no fever |
| COVID | 350 | loss_of_smell, loss_of_taste, fever, cough |
| Allergy | 300 | sneezing, itchy_eyes, no fever |
| Migraine | 250 | headache, sensitivity_to_light, no fever |
| Stomach Infection | 300 | stomach_pain, nausea, vomiting |
| UTI | 250 | burning_urination, frequent_urination |
| Dehydration | 200 | thirst, dry_mouth, vomiting/diarrhea |
| Anxiety | 250 | anxiety, rapid_heartbeat, trembling |
| Food Poisoning | 300 | nausea, vomiting, diarrhea |

## Medical Accuracy

The dataset generator uses medically accurate correlations:

### Flu
- ✅ Fever + body ache + chills (high correlation)
- ✅ Cough + fatigue
- ❌ Rarely runny nose (distinguishes from cold)

### COVID-19
- ✅ Loss of smell/taste (strong indicator)
- ✅ Fever + cough + difficulty breathing
- ✅ Body ache + fatigue

### Common Cold
- ✅ Runny nose + congestion + sneezing
- ❌ No fever (usually)
- ❌ No body ache

### Allergy
- ✅ Sneezing + itchy eyes + runny nose
- ❌ NO fever
- ❌ NO body ache

### UTI
- ✅ Burning urination + frequent urination
- ❌ NO respiratory symptoms

### Food Poisoning
- ✅ Nausea + vomiting + diarrhea (acute)
- ✅ Stomach cramps

## Using Existing Dataset

If you have an existing dataset (`baymax_dataset.csv`), place it in:
```
src/ann/train/datasets/baymax_dataset.csv
```

The training scripts will automatically use it if `medical_dataset_3000.csv` is not found.

## Dataset Preprocessing

The dataset loader (`src/ann/train/datasetLoader.ts`) handles:

1. **CSV Parsing**: Handles quoted values and commas
2. **Feature Mapping**: Maps 39 dataset symptoms to 50-symptom vocabulary
3. **Label Mapping**: Maps dataset labels to disease classes
4. **Normalization**: Age, duration, and other features normalized to 0-1

## Custom Datasets

To use your own dataset:

1. **Format**: CSV with same structure
2. **Place**: `src/ann/train/datasets/your_dataset.csv`
3. **Update**: Modify `datasetLoader.ts` if structure differs

## Validation

The dataset includes validation:
- ✅ No contradictory symptoms (e.g., diarrhea + constipation)
- ✅ Medically consistent symptom combinations
- ✅ Realistic severity distributions
- ✅ Age-appropriate symptoms

## Statistics

After generation, you'll see:
- Total samples
- Label distribution
- File locations

Example output:
```
Generated 3000 samples
Label distribution: {
  flu: 400,
  common_cold: 400,
  covid: 350,
  ...
}
Saved CSV to: src/ann/train/datasets/medical_dataset_3000.csv
```

