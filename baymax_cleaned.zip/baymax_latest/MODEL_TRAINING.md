# Model Training Guide

This guide explains how to train the Baymax Health Advisor ANN models.

## Prerequisites

1. **Generate Dataset** (if not using existing dataset):
   ```bash
   npm run generate-dataset
   ```
   This creates `src/ann/train/datasets/medical_dataset_3000.csv` with 3000 medically accurate samples.

2. **Install Dependencies**:
   ```bash
   npm install
   ```

## Training All Models

To train all three models (Disease Classifier, Risk Engine, Consistency Checker):

```bash
npm run train
```

This will:
- Load the dataset
- Split into training (80%) and test (20%) sets
- Train each model with proper validation
- Evaluate on test set
- Save models to `models/` directory
- Display comprehensive metrics

## Training Individual Models

### Disease Classifier

```bash
ts-node src/ann/train/trainDiseaseModel.ts
```

**Architecture:**
- Input: 52 features (50 symptoms + 2 metadata)
- Dense(128, relu)
- Dense(64, relu)
- Dropout(0.25)
- Dense(32, relu)
- Dense(10, softmax) - 10 disease classes

**Metrics:**
- Accuracy
- Precision, Recall, F1 per class
- Macro F1, Weighted F1
- ROC-AUC
- Confusion Matrix

### Risk Engine

```bash
ts-node src/ann/train/trainRiskModel.ts
```

**Architecture:**
- Input: 52 features
- Dense(96, relu)
- Dropout(0.3)
- Dense(48, relu)
- Dense(24, relu)
- Dense(5, sigmoid) - [riskLevel, emergencyScore, progressionScore, dehydrationRisk, infectionSpread]

### Consistency Checker

```bash
ts-node src/ann/train/trainConsistencyModel.ts
```

**Architecture:**
- Input: 52 features
- Dense(64, relu)
- Dropout(0.3)
- Dense(32, relu)
- Dense(3, sigmoid) - [consistencyScore, manipulationScore, warningScore]

## Model Outputs

Trained models are saved to:
- `models/disease/` - Disease classifier
- `models/risk/` - Risk engine
- `models/consistency/` - Consistency checker

Each model directory contains:
- `model.json` - Model architecture
- `weights.bin` - Model weights

## Training Parameters

### Disease Classifier
- **Epochs**: 100
- **Batch Size**: 32
- **Validation Split**: 20%
- **Optimizer**: Adam (lr=0.001)
- **Loss**: Categorical Crossentropy

### Risk Engine
- **Epochs**: 80
- **Batch Size**: 32
- **Validation Split**: 20%
- **Optimizer**: Adam (lr=0.001)
- **Loss**: Mean Squared Error

### Consistency Checker
- **Epochs**: 50
- **Batch Size**: 32
- **Validation Split**: 20%
- **Optimizer**: Adam (lr=0.001)
- **Loss**: Mean Squared Error

## Evaluation Metrics

After training, you'll see:

1. **Overall Metrics:**
   - Accuracy
   - Macro F1
   - Weighted F1
   - ROC-AUC

2. **Per-Class Metrics:**
   - Precision
   - Recall
   - F1 Score

3. **Confusion Matrix:**
   - Shows prediction vs actual for each disease class

## Tips

1. **Monitor Training**: Watch for overfitting (validation loss increasing while training loss decreases)

2. **Adjust Epochs**: If validation loss plateaus early, reduce epochs

3. **Batch Size**: Larger batches (64) may improve stability but slower training

4. **Learning Rate**: If loss doesn't decrease, try lower learning rate (0.0001)

5. **Dataset Size**: More data = better performance. Consider generating more samples if accuracy is low.

## Troubleshooting

**Error: "Dataset not found"**
- Run `npm run generate-dataset` first
- Or ensure `baymax_dataset.csv` exists in `src/ann/train/datasets/`

**Error: "Out of memory"**
- Reduce batch size (e.g., 16 instead of 32)
- Reduce number of epochs
- Close other applications

**Low Accuracy**
- Check dataset quality
- Increase training epochs
- Adjust model architecture
- Add more training data

**Models not loading**
- Ensure models were saved successfully
- Check file paths in `models/` directory
- Models will auto-initialize if not found

