# Quick Start Guide

## Installation

1. **Install dependencies**:
```bash
npm install
```

2. **Set up environment variables** (optional):
```bash
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY if you want LLM features
```

## Running the Server

### Development Mode
```bash
npm run dev
```

### Production Mode
```bash
npm run build
npm start
```

The server will start on `http://localhost:3000` (or the port specified in `.env`).

## Testing the API

### Health Check
```bash
curl http://localhost:3000/api/health
```

### Analyze Symptoms
```bash
curl -X POST http://localhost:3000/api/advice \
  -H "Content-Type: application/json" \
  -d '{
    "symptoms": ["fever", "cough", "body_ache"],
    "severity": {
      "fever": 7,
      "cough": 6,
      "body_ache": 7
    },
    "duration": 24,
    "age": 35
  }'
```

## Running Examples

```bash
npm run example
```

This will run example analyses with different symptom patterns.

## Training Models

To train the ANN models (uses synthetic data):

```bash
npm run train
```

**Note**: For production, replace synthetic data with real medical datasets.

## Project Structure

- `src/ann/` - Neural network models
- `src/rules/` - Medical rule engine
- `src/llm/` - LLM integration
- `src/pipeline/` - Main analysis pipeline
- `src/routes/` - API endpoints
- `src/types/` - TypeScript type definitions

## Key Features

✅ **Symptom Consistency Checker** - Detects wrong/contradictory inputs  
✅ **Disease Prediction ANN** - Predicts top 10 disease probabilities  
✅ **Risk Engine ANN** - Assesses emergency and progression risk  
✅ **Medical Rule Engine** - Applies medical knowledge  
✅ **LLM Validation** - Validates symptoms with GPT-4 (optional)  
✅ **Hybrid Pipeline** - Combines all components  
✅ **Natural Language Advice** - Friendly health recommendations  

## API Endpoints

- `GET /` - API information
- `GET /api/health` - Health check
- `POST /api/advice` - Analyze symptoms

See `API.md` for detailed API documentation.

## Environment Variables

- `OPENAI_API_KEY` (optional) - OpenAI API key for LLM features
- `PORT` (optional) - Server port (default: 3000)

## Notes

- The system works without OpenAI API key (uses mock LLM)
- Models initialize on first request (may take a few seconds)
- All models use TensorFlow.js for Node.js
- The system is for informational purposes only

