# Baymax Health Advisor - AI Brain Backend

Production-ready backend module for health symptom analysis using ANN + Risk Engine + Symptom Validation Pipeline.

## 🎯 Features

- **Symptom Consistency Checker ANN**: Detects wrong/contradictory inputs
- **Symptom → Disease Probability ANN**: Main disease classifier (10 disease categories)
- **Early Disease Risk Prediction ANN**: Risk assessment engine
- **Medical Rule Engine**: Knowledge graph logic with medical rules
- **LLM Validator Layer**: OpenAI GPT-4 validation (with mock fallback)
- **Hybrid Pipeline**: Merges all components into unified analysis
- **REST API**: Express.js server with health check and advice endpoints

## 🚀 Quick Start

### Backend

```bash
# Install dependencies
npm install

# Build TypeScript
npm run build

# Start server
npm start

# Or run in development mode
npm run dev
```

### Frontend

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

The frontend will be available at `http://localhost:5173` and connects to the backend API.

## 📋 Environment Variables

Create a `.env` file (optional):

```
OPENAI_API_KEY=your_api_key_here  # Optional: uses mock LLM if not set
PORT=3000                          # Optional: defaults to 3000
```

## 📚 Documentation

- **[Quick Start Guide](QUICKSTART.md)** - Get started quickly
- **[API Documentation](API.md)** - Complete API reference
- **[Architecture](ARCHITECTURE.md)** - System architecture details

## 🧪 Usage Examples

### Run Example Analysis
```bash
npm run example
```

### API Request
```bash
curl -X POST http://localhost:3000/api/advice \
  -H "Content-Type: application/json" \
  -d '{
    "symptoms": ["fever", "cough", "body_ache"],
    "severity": {
      "fever": 7,
      "cough": 6,
      "body_ache": 7
    },
    "duration": 24,
    "age": 35
  }'
```

## 🏗️ Project Structure

```
baymax_latest/
├── src/                    # Backend source code
│   ├── ann/                # Neural network models
│   ├── rules/              # Medical rule engine
│   ├── llm/                # LLM integration
│   ├── pipeline/            # Main pipeline
│   ├── routes/              # API routes
│   └── types/               # TypeScript types
├── frontend/               # React frontend
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── api/            # API service
│   │   └── types.ts        # TypeScript types
│   └── package.json
└── package.json            # Backend package.json
```

## 🧠 Model Training

Train all models (uses synthetic data by default):

```bash
npm run train
```

**Note**: Replace synthetic data with real medical datasets for production use.

## 📊 API Endpoints

- `GET /` - API information
- `GET /api/health` - Health check
- `POST /api/advice` - Analyze symptoms and get health report

## 🎨 Frontend

A modern React frontend is included in the `frontend/` directory. It provides:

- Interactive symptom selection form
- Real-time health analysis
- Beautiful report visualization
- Responsive design

See `frontend/README.md` for frontend-specific documentation.

## 🔧 Technology Stack

- **Node.js** + **TypeScript**
- **TensorFlow.js** - Neural network models
- **Express.js** - Web framework
- **OpenAI GPT-4** - LLM features (optional)

## ⚠️ Important Notes

- This system is for **informational purposes only**
- **Not a replacement** for professional medical advice
- Models use synthetic data by default (replace with real datasets)
- LLM features work without API key (uses mock responses)

## 📝 License

MIT

