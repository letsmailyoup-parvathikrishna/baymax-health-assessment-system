@echo off
echo Copying baymax_medical_dataset_v2_5000.csv to datasets folder...
copy "c:\Users\ADMIN\Downloads\baymax_medical_dataset_v2_5000.csv" "src\ann\train\datasets\baymax_medical_dataset_v2_5000.csv"
if %ERRORLEVEL% EQU 0 (
    echo File copied successfully!
    dir "src\ann\train\datasets\baymax_medical_dataset_v2_5000.csv"
) else (
    echo Error copying file. Please check if source file exists.
    pause
)

