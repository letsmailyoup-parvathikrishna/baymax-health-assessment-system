# Baymax Health Advisor - Frontend

Modern React frontend for the Baymax Health Advisor health analysis system.

## ✨ Features

- 🎨 Beautiful, modern UI with gradient design
- 📝 Interactive symptom selection form (50 symptoms)
- 📊 Comprehensive health report display
- 🔍 Detailed validation and rule engine information
- 📱 Fully responsive design for mobile and desktop
- ⚡ Fast and lightweight with Vite
- 🔄 Real-time API integration
- 🎯 Loading states and error handling

## 🚀 Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📋 Configuration

The frontend connects to the backend API. By default, it expects the backend to run on `http://localhost:3000`.

You can configure the API URL by creating a `.env` file:

```
VITE_API_URL=http://localhost:3000
```

## 🎯 Usage

1. **Start the backend server** (from the root directory):
   ```bash
   npm run dev
   ```

2. **Start the frontend** (from the frontend directory):
   ```bash
   npm run dev
   ```

3. **Open your browser** to `http://localhost:5173`

4. **Select symptoms**, set severity levels, and submit to get a health analysis!

## 📊 Features Overview

### Symptom Selection
- 50 medical symptoms available
- Checkbox-based selection
- Real-time symptom count
- Organized grid layout

### Severity Rating
- Slider-based severity input (0-10)
- Visual feedback
- Per-symptom customization

### Health Report Display
- **Top Disease Probabilities**: Visual progress bars with percentages
- **Risk Assessment**: Color-coded risk levels (low/medium/high)
- **Baymax's Advice**: Natural language health recommendations
- **Rule Engine Warnings**: Medical rule corrections
- **Technical Details**: Expandable validation information
  - Consistency checks
  - LLM validation
  - Rule engine corrections

## 🎨 UI Components

### Form Components
- `SymptomForm.tsx` - Main symptom input form
- Responsive grid layout
- Interactive severity sliders
- Form validation

### Report Components
- `HealthReport.tsx` - Comprehensive health report display
- Color-coded risk indicators
- Expandable technical details
- Beautiful card-based layout

## 📁 Project Structure

```
frontend/
├── src/
│   ├── components/      # React components
│   │   ├── SymptomForm.tsx
│   │   └── HealthReport.tsx
│   ├── api/            # API service
│   │   └── healthApi.ts
│   ├── types.ts        # TypeScript types
│   ├── App.tsx         # Main app component
│   ├── App.css         # Styles
│   ├── main.tsx        # Entry point
│   └── vite-env.d.ts   # Vite type definitions
├── index.html
├── vite.config.ts
└── package.json
```

## 🛠️ Technologies

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool and dev server
- **Axios** - HTTP client
- **CSS3** - Modern styling with animations

## 🎨 Design Features

- Gradient backgrounds
- Smooth animations
- Color-coded risk levels
- Responsive grid layouts
- Loading spinners
- Error handling
- Expandable sections
- Card-based design

## 📱 Responsive Design

The frontend is fully responsive and works on:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (< 768px)

## 🔧 Development

### Hot Module Replacement
Vite provides instant HMR for fast development.

### TypeScript
Full type safety with TypeScript interfaces matching backend types.

### API Integration
- Automatic proxy configuration for development
- Error handling with user-friendly messages
- Loading states during API calls

## 🐛 Troubleshooting

**Backend not connecting?**
- Ensure backend is running on `http://localhost:3000`
- Check CORS settings if using different ports
- Verify API URL in `.env` file

**Build errors?**
- Run `npm install` to ensure all dependencies are installed
- Check Node.js version (requires Node 18+)
- Clear `node_modules` and reinstall if needed

**Styling issues?**
- Clear browser cache
- Check CSS file is imported in `App.tsx`

## 📝 Notes

- The frontend automatically handles API errors
- Loading states provide user feedback
- All form inputs are validated
- Report displays all backend analysis results
