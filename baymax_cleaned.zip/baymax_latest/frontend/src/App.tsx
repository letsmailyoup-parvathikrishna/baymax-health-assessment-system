import { useState } from 'react';
import { SymptomForm } from './components/SymptomForm';
import { HealthReport } from './components/HealthReport';
import { healthApi } from './api/healthApi';
import { UserSymptomInput, BaymaxHealthReport } from './types';
import './App.css';

function App() {
  const [report, setReport] = useState<BaymaxHealthReport | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (input: UserSymptomInput) => {
    setIsLoading(true);
    setError(null);
    setReport(null);

    try {
      const result = await healthApi.analyzeSymptoms(input);
      setReport(result);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Failed to analyze symptoms. Make sure the backend is running.');
      console.error('Error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setReport(null);
    setError(null);
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>🤖 Baymax Health Advisor</h1>
        <p>Your friendly healthcare companion powered by AI</p>
        <div className="header-badges">
          <span className="badge">ANN + LLM + Rules</span>
          <span className="badge">10 Disease Classes</span>
          <span className="badge">Real-time Analysis</span>
        </div>
      </header>

      <main className="app-main">
        {!report ? (
          <div className="form-container">
            <SymptomForm onSubmit={handleSubmit} isLoading={isLoading} />
            {error && (
              <div className="error-message">
                <strong>Error:</strong> {error}
                <br />
                <small>Make sure the backend server is running on http://localhost:3000</small>
              </div>
            )}
          </div>
        ) : (
          <div className="report-container">
            <button onClick={handleReset} className="reset-button">
              ← New Analysis
            </button>
            <HealthReport report={report} />
          </div>
        )}
      </main>

      <footer className="app-footer">
        <p>
          ⚠️ This system is for informational purposes only and should not replace professional medical advice.
          If you have serious symptoms, please consult a healthcare provider.
        </p>
      </footer>
    </div>
  );
}

export default App;

