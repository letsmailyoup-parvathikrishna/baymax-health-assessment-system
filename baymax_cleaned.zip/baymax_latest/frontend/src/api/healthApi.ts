import axios from 'axios';
import { UserSymptomInput, BaymaxHealthReport } from '../types';

const API_BASE_URL = (import.meta as any).env?.VITE_API_URL || 'http://localhost:3000';

export const healthApi = {
  async analyzeSymptoms(input: UserSymptomInput): Promise<BaymaxHealthReport> {
    const response = await axios.post<BaymaxHealthReport>(
      `${API_BASE_URL}/api/advice`,
      input
    );
    return response.data;
  },

  async healthCheck(): Promise<{ status: string; service: string; timestamp: string }> {
    const response = await axios.get(`${API_BASE_URL}/api/health`);
    return response.data;
  }
};

