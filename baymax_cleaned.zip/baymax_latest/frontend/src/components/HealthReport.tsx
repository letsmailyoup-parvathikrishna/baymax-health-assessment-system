import { BaymaxHealthReport } from '../types';

interface HealthReportProps {
  report: BaymaxHealthReport;
}

export function HealthReport({ report }: HealthReportProps) {
  const topDiseases = Object.entries(report.ann.diseaseProbabilities)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel.toLowerCase()) {
      case 'high': return '#ef4444';
      case 'medium': return '#f59e0b';
      case 'low': return '#10b981';
      default: return '#6b7280';
    }
  };

  const getSeverityColor = (severity: number) => {
    if (severity >= 70) return '#ef4444';
    if (severity >= 40) return '#f59e0b';
    return '#10b981';
  };

  return (
    <div className="health-report">
      <div className="report-header">
        <h1>🏥 Health Analysis Report</h1>
        <div className="confidence-badge">
          Confidence: {report.meta.confidence}%
        </div>
      </div>

      {report.meta.warnings.length > 0 && (
        <div className="warnings-section">
          <h3>⚠️ Warnings</h3>
          <ul>
            {report.meta.warnings.map((warning, idx) => (
              <li key={idx}>{warning}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="report-grid">
        <div className="report-card">
          <h3>Top Disease Probabilities</h3>
          <p className="card-description">Based on ANN analysis and medical rules</p>
          <div className="disease-list">
            {topDiseases.map(([disease, probability]) => (
              <div key={disease} className="disease-item">
                <div className="disease-name">
                  {disease.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </div>
                <div className="disease-probability">
                  <div className="probability-bar">
                    <div
                      className="probability-fill"
                      style={{ 
                        width: `${probability * 100}%`,
                        backgroundColor: probability > 0.5 ? '#ef4444' : probability > 0.3 ? '#f59e0b' : '#667eea'
                      }}
                    />
                  </div>
                  <span className="probability-value">{(probability * 100).toFixed(1)}%</span>
                </div>
              </div>
            ))}
          </div>
          {topDiseases.length === 0 && (
            <p className="no-data">No disease probabilities available</p>
          )}
        </div>

        <div className="report-card">
          <h3>Risk Assessment</h3>
          <p className="card-description">Emergency and progression risk analysis</p>
          <div className="risk-info">
            <div className="risk-item">
              <span className="risk-label">Risk Level:</span>
              <span
                className="risk-value"
                style={{ color: getRiskColor(report.ann.riskEngine.riskLevel) }}
              >
                {report.ann.riskEngine.riskLevel.toUpperCase()}
              </span>
            </div>
            <div className="risk-item">
              <span className="risk-label">Emergency Score:</span>
              <span className="risk-value">{report.ann.riskEngine.emergencyScore}/100</span>
            </div>
            <div className="risk-item">
              <span className="risk-label">Progression Score:</span>
              <span className="risk-value">{report.ann.riskEngine.progressionScore}/100</span>
            </div>
            <div className="risk-item">
              <span className="risk-label">Severity:</span>
              <span
                className="risk-value"
                style={{ color: getSeverityColor(report.ann.severity) }}
              >
                {report.ann.severity}/100
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="advice-section">
        <h3>💬 Baymax's Advice</h3>
        <p className="card-description">Personalized health recommendations</p>
        <div className="advice-text">
          {report.finalAdvice.split('\n').map((line, idx) => {
            if (!line.trim()) return <br key={idx} />;
            return <p key={idx}>{line}</p>;
          })}
        </div>
      </div>

      {report.ruleEngine.ruleWarnings.length > 0 && (
        <div className="rule-warnings-section">
          <h3>📋 Rule Engine Warnings</h3>
          <ul>
            {report.ruleEngine.ruleWarnings.map((warning, idx) => (
              <li key={idx}>{warning}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="validation-section">
        <details>
          <summary>🔍 Technical Validation Details</summary>
          <div className="validation-details">
            <div className="validation-group">
              <h4>Consistency Check</h4>
              <div>
                <strong>Consistency Score:</strong> {(report.validation.consistencyChecks.consistencyScore * 100).toFixed(1)}%
              </div>
              <div>
                <strong>Manipulation Detected:</strong> {report.validation.consistencyChecks.isManipulated ? '⚠️ Yes' : '✅ No'}
              </div>
              {report.validation.consistencyChecks.warnings.length > 0 && (
                <div>
                  <strong>Warnings:</strong> {report.validation.consistencyChecks.warnings.join(', ')}
                </div>
              )}
            </div>

            <div className="validation-group">
              <h4>LLM Validation</h4>
              <div>
                <strong>Logical:</strong> {report.validation.llmChecks.logical ? '✅ Yes' : '⚠️ No'}
              </div>
              {report.validation.llmChecks.issues.length > 0 && (
                <div>
                  <strong>Issues:</strong> {report.validation.llmChecks.issues.join(', ')}
                </div>
              )}
              {report.validation.llmChecks.contradictions.length > 0 && (
                <div>
                  <strong>Contradictions:</strong> {report.validation.llmChecks.contradictions.join(', ')}
                </div>
              )}
              {report.validation.llmChecks.impossible.length > 0 && (
                <div>
                  <strong>Impossible:</strong> {report.validation.llmChecks.impossible.join(', ')}
                </div>
              )}
            </div>

            <div className="validation-group">
              <h4>Rule Engine Corrections</h4>
              <div>
                <strong>Rules Applied:</strong> {report.ruleEngine.ruleWarnings.length > 0 ? 'Yes' : 'No'}
              </div>
              <div className="probability-comparison">
                <strong>Top 3 Diseases (After Rule Correction):</strong>
                <ul>
                  {Object.entries(report.ruleEngine.corrected)
                    .sort((a, b) => b[1] - a[1])
                    .slice(0, 3)
                    .map(([disease, prob]) => (
                      <li key={disease}>
                        {disease.replace(/_/g, ' ')}: {(prob * 100).toFixed(1)}%
                      </li>
                    ))}
                </ul>
              </div>
            </div>
          </div>
        </details>
      </div>
    </div>
  );
}


