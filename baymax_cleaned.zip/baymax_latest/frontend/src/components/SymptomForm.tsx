import { useState } from 'react';
import { SYMPTOM_OPTIONS, UserSymptomInput } from '../types';

interface SymptomFormProps {
  onSubmit: (input: UserSymptomInput) => void;
  isLoading: boolean;
}

export function SymptomForm({ onSubmit, isLoading }: SymptomFormProps) {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [severities, setSeverities] = useState<Record<string, number>>({});
  const [duration, setDuration] = useState<number>(24);
  const [age, setAge] = useState<number>(30);
  const [gender, setGender] = useState<string>('');

  const toggleSymptom = (symptom: string) => {
    if (selectedSymptoms.includes(symptom)) {
      setSelectedSymptoms(selectedSymptoms.filter(s => s !== symptom));
      const newSeverities = { ...severities };
      delete newSeverities[symptom];
      setSeverities(newSeverities);
    } else {
      setSelectedSymptoms([...selectedSymptoms, symptom]);
      setSeverities({ ...severities, [symptom]: 5 });
    }
  };

  const updateSeverity = (symptom: string, severity: number) => {
    setSeverities({ ...severities, [symptom]: severity });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedSymptoms.length === 0) {
      alert('Please select at least one symptom');
      return;
    }

    onSubmit({
      symptoms: selectedSymptoms,
      severity: severities,
      duration,
      age,
      gender: gender || undefined
    });
  };

  return (
    <form onSubmit={handleSubmit} className="symptom-form">
      <div className="form-section">
        <h2>Select Your Symptoms</h2>
        <p className="section-description">Select all symptoms you're currently experiencing</p>
        <div className="symptom-grid">
          {SYMPTOM_OPTIONS.map(symptom => (
            <label key={symptom} className="symptom-checkbox">
              <input
                type="checkbox"
                checked={selectedSymptoms.includes(symptom)}
                onChange={() => toggleSymptom(symptom)}
              />
              <span>{symptom.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
            </label>
          ))}
        </div>
        {selectedSymptoms.length > 0 && (
          <p className="selected-count">
            {selectedSymptoms.length} symptom{selectedSymptoms.length !== 1 ? 's' : ''} selected
          </p>
        )}
      </div>

      {selectedSymptoms.length > 0 && (
        <div className="form-section">
          <h2>Rate Symptom Severity (0-10)</h2>
          <div className="severity-list">
            {selectedSymptoms.map(symptom => (
              <div key={symptom} className="severity-item">
                <label>{symptom.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</label>
                <div className="severity-controls">
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={severities[symptom] || 5}
                    onChange={(e) => updateSeverity(symptom, parseInt(e.target.value))}
                    className="severity-slider"
                  />
                  <span className="severity-value">{severities[symptom] || 5}/10</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="form-section">
        <h2>Additional Information</h2>
        <p className="section-description">Help improve accuracy with additional details</p>
        <div className="form-row">
          <div className="form-group">
            <label>Duration (hours) <span className="required">*</span></label>
            <input
              type="number"
              min="0"
              max="168"
              value={duration}
              onChange={(e) => setDuration(parseInt(e.target.value) || 0)}
              placeholder="e.g., 24"
              required
            />
            <small>How long have you had these symptoms?</small>
          </div>
          <div className="form-group">
            <label>Age</label>
            <input
              type="number"
              min="0"
              max="120"
              value={age}
              onChange={(e) => setAge(parseInt(e.target.value) || 0)}
              placeholder="e.g., 35"
            />
            <small>Optional but helps with accuracy</small>
          </div>
          <div className="form-group">
            <label>Gender</label>
            <select value={gender} onChange={(e) => setGender(e.target.value)}>
              <option value="">Prefer not to say</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
            <small>Optional</small>
          </div>
        </div>
      </div>

      <button type="submit" className="submit-button" disabled={isLoading || selectedSymptoms.length === 0}>
        {isLoading ? (
          <>
            <span className="loading-spinner"></span>
            Analyzing Symptoms...
          </>
        ) : (
          'Get Health Analysis'
        )}
      </button>
    </form>
  );
}

