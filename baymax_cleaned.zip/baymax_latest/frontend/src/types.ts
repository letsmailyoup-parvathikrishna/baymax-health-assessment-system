export interface UserSymptomInput {
  symptoms: string[];
  severity: Record<string, number>;
  duration: number;
  age?: number;
  gender?: string;
  existingConditions?: string[];
}

export interface BaymaxHealthReport {
  meta: {
    confidence: number;
    warnings: string[];
  };
  ann: {
    diseaseProbabilities: Record<string, number>;
    severity: number;
    riskEngine: {
      riskLevel: string;
      emergencyScore: number;
      progressionScore: number;
    };
  };
  ruleEngine: {
    corrected: Record<string, number>;
    ruleWarnings: string[];
  };
  validation: {
    llmChecks: {
      logical: boolean;
      issues: string[];
      contradictions: string[];
      impossible: string[];
    };
    consistencyChecks: {
      consistencyScore: number;
      warnings: string[];
      isManipulated: boolean;
    };
  };
  finalAdvice: string;
}

// Complete symptom vocabulary matching backend (50 symptoms)
export const SYMPTOM_OPTIONS = [
  'fever', 'cough', 'runny_nose', 'sore_throat', 'headache',
  'body_ache', 'fatigue', 'loss_of_smell', 'loss_of_taste',
  'nausea', 'vomiting', 'diarrhea', 'stomach_cramps', 'chest_pain',
  'difficulty_breathing', 'shortness_of_breath', 'dizziness', 
  'rapid_heartbeat', 'chills', 'rash', 'itchy_skin', 'joint_pain',
  'burning_urination', 'frequent_urination', 'lower_abdominal_pain',
  'bloating', 'gas', 'dehydration_signs', 'dry_mouth',
  'sensitivity_to_light', 'anxiety', 'restlessness', 'trembling',
  'sweating', 'irritability', 'trouble_sleeping', 'appetite_loss',
  'weight_loss', 'weight_gain', 'throat_itchiness', 'congestion',
  'wheezing', 'sneezing', 'itchy_eyes', 'stomach_pain', 
  'abdominal_cramps', 'back_pain', 'sore_muscles', 'thirst',
  'confusion'
];

