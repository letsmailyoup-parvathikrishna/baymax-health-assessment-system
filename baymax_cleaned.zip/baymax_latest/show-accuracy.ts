import * as path from 'path';
import * as fs from 'fs';

console.log('========================================');
console.log('   Baymax Health Advisor - Model Accuracy');
console.log('========================================\n');

console.log('📊 MODEL STATUS:\n');

// Check if models exist
const modelsDir = path.join(__dirname, 'models');
const diseaseModel = path.join(modelsDir, 'disease', 'model.json');
const riskModel = path.join(modelsDir, 'risk', 'model.json');
const consistencyModel = path.join(modelsDir, 'consistency', 'model.json');

console.log('Disease Classifier Model:');
if (fs.existsSync(diseaseModel)) {
  console.log('  ✅ Model file exists');
  console.log('  📍 Location: models/disease/');
} else {
  console.log('  ⚠️  Model not trained yet');
  console.log('  💡 Run: npm run train');
}

console.log('\nRisk Engine Model:');
if (fs.existsSync(riskModel)) {
  console.log('  ✅ Model file exists');
  console.log('  📍 Location: models/risk/');
} else {
  console.log('  ⚠️  Model not trained yet');
  console.log('  💡 Run: npm run train');
}

console.log('\nConsistency Checker Model:');
if (fs.existsSync(consistencyModel)) {
  console.log('  ✅ Model file exists');
  console.log('  📍 Location: models/consistency/');
} else {
  console.log('  ⚠️  Model not trained yet');
  console.log('  💡 Run: npm run train');
}

console.log('\n========================================');
console.log('📈 EXPECTED ACCURACY (After Training):');
console.log('========================================\n');

console.log('Disease Classifier:');
console.log('  • Accuracy: ~85-95%');
console.log('  • Precision: ~80-90% per class');
console.log('  • Recall: ~75-90% per class');
console.log('  • F1 Score: ~80-90%');
console.log('  • ROC-AUC: ~0.85-0.95\n');

console.log('Risk Engine:');
console.log('  • Mean Squared Error: < 0.1');
console.log('  • Correlation: > 0.85');
console.log('  • Risk Level Accuracy: ~80-90%\n');

console.log('Consistency Checker:');
console.log('  • Manipulation Detection: ~90-95%');
console.log('  • Consistency Score Accuracy: ~85-90%');
console.log('  • False Positive Rate: < 5%\n');

console.log('========================================');
console.log('💡 To see actual accuracy, run:');
console.log('   npm run train');
console.log('========================================\n');

