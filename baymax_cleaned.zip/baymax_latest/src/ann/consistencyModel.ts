import * as tf from '@tensorflow/tfjs';
import { UserSymptomInput, ConsistencyCheckResult } from '../types';
import { symptomsToVector, createInputTensor } from './preprocess';

export class ConsistencyCheckerModel {
  private model: tf.LayersModel | null = null;
  private isInitialized = false;

  /**
   * Initialize or create the consistency checker model
   */
  async initialize(): Promise<void> {
    if (this.isInitialized && this.model) {
      return;
    }

    // Create a simple feedforward network
    this.model = tf.sequential({
      layers: [
        tf.layers.dense({
          inputShape: [52], // SYMPTOM_VOCAB.length (50) + 2 metadata
          units: 64,
          activation: 'relu',
          name: 'hidden1'
        }),
        tf.layers.dropout({ rate: 0.3 }),
        tf.layers.dense({
          units: 32,
          activation: 'relu',
          name: 'hidden2'
        }),
        tf.layers.dense({
          units: 3, // [consistency_score, manipulation_score, warning_score]
          activation: 'sigmoid',
          name: 'output'
        })
      ]
    });

    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'meanSquaredError',
      metrics: ['accuracy']
    });

    this.isInitialized = true;
  }

  /**
   * Check symptom consistency
   */
  async checkConsistency(input: UserSymptomInput): Promise<ConsistencyCheckResult> {
    await this.initialize();

    if (!this.model) {
      throw new Error('Model not initialized');
    }

    const features = symptomsToVector(input);
    const tensor = createInputTensor(features);
    
    const prediction = this.model.predict(tensor) as tf.Tensor;
    const values = await prediction.data();
    prediction.dispose();
    tensor.dispose();

    const consistencyScore = values[0];
    const manipulationScore = values[1];
    const warningScore = values[2];

    const warnings: string[] = [];
    let isManipulated = false;

    // Rule-based checks
    const symptomSet = new Set(input.symptoms.map(s => s.toLowerCase()));
    
    // Check for contradictions
    if (symptomSet.has('fever') && symptomSet.has('chills') && !symptomSet.has('sweating')) {
      warnings.push('Fever and chills together may indicate infection');
    }

    if (symptomSet.has('diarrhea') && symptomSet.has('constipation')) {
      warnings.push('Contradictory symptoms: diarrhea and constipation');
    }

    if (symptomSet.has('runny_nose') && symptomSet.has('dry_mouth')) {
      warnings.push('Unusual combination: runny nose with dry mouth');
    }

    // Check for unrealistic severity patterns
    const severities = Object.values(input.severity);
    const maxSeverity = Math.max(...severities, 0);
    const avgSeverity = severities.length > 0 
      ? severities.reduce((a, b) => a + b, 0) / severities.length 
      : 0;

    if (maxSeverity > 8 && avgSeverity < 3) {
      warnings.push('Unrealistic severity pattern detected');
      isManipulated = true;
    }

    // Check for impossible combinations
    if (symptomSet.has('chest_pain') && symptomSet.has('runny_nose') && 
        symptomSet.has('sneezing') && !symptomSet.has('cough')) {
      warnings.push('Chest pain with allergy symptoms may need medical attention');
    }

    // High manipulation score or many warnings
    if (manipulationScore > 0.7 || warnings.length > 3) {
      isManipulated = true;
    }

    // Adjust consistency score based on warnings
    const adjustedScore = Math.max(0, consistencyScore - (warnings.length * 0.1));

    return {
      consistencyScore: adjustedScore,
      warnings,
      isManipulated
    };
  }

  /**
   * Get model summary
   */
  getModel(): tf.LayersModel | null {
    return this.model;
  }
}

