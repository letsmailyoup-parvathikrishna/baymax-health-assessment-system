import * as tf from '@tensorflow/tfjs';
import { UserSymptomInput, DiseaseProbabilities } from '../types';
import { symptomsToVector, createInputTensor, DISEASE_CLASSES, normalizeProbabilities } from './preprocess';

export class DiseasePredictionModel {
  private model: tf.LayersModel | null = null;
  private isInitialized = false;

  /**
   * Initialize or create the disease prediction model
   */
  async initialize(): Promise<void> {
    if (this.isInitialized && this.model) {
      return;
    }

    // Create a deeper network for disease classification
    this.model = tf.sequential({
      layers: [
        tf.layers.dense({
          inputShape: [52], // SYMPTOM_VOCAB.length (50) + 2 metadata
          units: 128,
          activation: 'relu',
          name: 'hidden1'
        }),
        tf.layers.dropout({ rate: 0.4 }),
        tf.layers.dense({
          units: 64,
          activation: 'relu',
          name: 'hidden2'
        }),
        tf.layers.dropout({ rate: 0.3 }),
        tf.layers.dense({
          units: 32,
          activation: 'relu',
          name: 'hidden3'
        }),
        tf.layers.dense({
          units: DISEASE_CLASSES.length, // 10 diseases
          activation: 'softmax',
          name: 'output'
        })
      ]
    });

    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'categoricalCrossentropy',
      metrics: ['accuracy']
    });

    this.isInitialized = true;
  }

  /**
   * Predict disease probabilities
   */
  async predict(input: UserSymptomInput): Promise<{
    probabilities: DiseaseProbabilities;
    severity: number;
    confidence: number;
  }> {
    await this.initialize();

    if (!this.model) {
      throw new Error('Model not initialized');
    }

    const features = symptomsToVector(input);
    const tensor = createInputTensor(features);
    
    const prediction = this.model.predict(tensor) as tf.Tensor;
    const values = await prediction.data();
    prediction.dispose();
    tensor.dispose();

    // Convert to array and normalize
    const probs = Array.from(values);
    const normalized = normalizeProbabilities(probs);

    // Create disease probabilities object
    const diseaseProbabilities: DiseaseProbabilities = {
      flu: normalized[0],
      cold: normalized[1],
      covid: normalized[2],
      allergy: normalized[3],
      migraine: normalized[4],
      stomach_infection: normalized[5],
      uti: normalized[6],
      dehydration: normalized[7],
      anxiety: normalized[8],
      food_poisoning: normalized[9]
    };

    // Calculate severity (0-100)
    const maxSeverity = Math.max(...Object.values(input.severity), 0);
    const avgSeverity = Object.values(input.severity).length > 0
      ? Object.values(input.severity).reduce((a, b) => a + b, 0) / Object.values(input.severity).length
      : 0;
    const severity = Math.min(100, (maxSeverity * 7) + (avgSeverity * 3));

    // Calculate confidence (based on max probability and spread)
    const maxProb = Math.max(...normalized);
    const entropy = -normalized.reduce((sum, p) => sum + (p > 0 ? p * Math.log2(p) : 0), 0);
    const maxEntropy = Math.log2(DISEASE_CLASSES.length);
    const confidence = maxProb * (1 - entropy / maxEntropy) * 100;

    return {
      probabilities: diseaseProbabilities,
      severity: Math.round(severity),
      confidence: Math.round(confidence)
    };
  }

  /**
   * Get model summary
   */
  getModel(): tf.LayersModel | null {
    return this.model;
  }
}

