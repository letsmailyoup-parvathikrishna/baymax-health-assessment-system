import * as tf from '@tensorflow/tfjs';

export interface ClassificationMetrics {
  accuracy: number;
  precision: number[];
  recall: number[];
  f1: number[];
  macroF1: number;
  weightedF1: number;
}

export interface ConfusionMatrix {
  matrix: number[][];
  labels: string[];
}

/**
 * Calculate accuracy
 */
export function calculateAccuracy(yTrue: tf.Tensor, yPred: tf.Tensor): number {
  const trueValues = yTrue.arraySync() as number[][];
  const predValues = yPred.arraySync() as number[][];
  
  let correct = 0;
  let total = 0;
  
  for (let i = 0; i < trueValues.length; i++) {
    const trueIdx = trueValues[i].indexOf(1);
    const predIdx = predValues[i].indexOf(Math.max(...predValues[i]));
    
    if (trueIdx === predIdx) {
      correct++;
    }
    total++;
  }
  
  return total > 0 ? correct / total : 0;
}

/**
 * Calculate precision, recall, and F1 for each class
 */
export function calculatePrecisionRecallF1(
  yTrue: tf.Tensor,
  yPred: tf.Tensor,
  numClasses: number
): { precision: number[]; recall: number[]; f1: number[] } {
  const trueValues = yTrue.arraySync() as number[][];
  const predValues = yPred.arraySync() as number[][];
  
  const truePositives = new Array(numClasses).fill(0);
  const falsePositives = new Array(numClasses).fill(0);
  const falseNegatives = new Array(numClasses).fill(0);
  
  for (let i = 0; i < trueValues.length; i++) {
    const trueClass = trueValues[i].indexOf(1);
    const predClass = predValues[i].indexOf(Math.max(...predValues[i]));
    
    if (trueClass === predClass) {
      truePositives[trueClass]++;
    } else {
      falsePositives[predClass]++;
      falseNegatives[trueClass]++;
    }
  }
  
  const precision: number[] = [];
  const recall: number[] = [];
  const f1: number[] = [];
  
  for (let i = 0; i < numClasses; i++) {
    const tp = truePositives[i];
    const fp = falsePositives[i];
    const fn = falseNegatives[i];
    
    const prec = tp + fp > 0 ? tp / (tp + fp) : 0;
    const rec = tp + fn > 0 ? tp / (tp + fn) : 0;
    const f1Score = prec + rec > 0 ? (2 * prec * rec) / (prec + rec) : 0;
    
    precision.push(prec);
    recall.push(rec);
    f1.push(f1Score);
  }
  
  return { precision, recall, f1 };
}

/**
 * Calculate macro and weighted F1
 */
export function calculateMacroWeightedF1(
  f1: number[],
  yTrue: tf.Tensor
): { macroF1: number; weightedF1: number } {
  const trueValues = yTrue.arraySync() as number[][];
  const classCounts = new Array(f1.length).fill(0);
  
  for (let i = 0; i < trueValues.length; i++) {
    const trueClass = trueValues[i].indexOf(1);
    classCounts[trueClass]++;
  }
  
  const macroF1 = f1.reduce((sum, f) => sum + f, 0) / f1.length;
  
  const total = classCounts.reduce((sum, count) => sum + count, 0);
  const weightedF1 = f1.reduce((sum, f, idx) => {
    return sum + (f * classCounts[idx]) / total;
  }, 0);
  
  return { macroF1, weightedF1 };
}

/**
 * Generate confusion matrix
 */
export function generateConfusionMatrix(
  yTrue: tf.Tensor,
  yPred: tf.Tensor,
  labels: string[]
): ConfusionMatrix {
  const trueValues = yTrue.arraySync() as number[][];
  const predValues = yPred.arraySync() as number[][];
  
  const numClasses = labels.length;
  const matrix: number[][] = Array(numClasses).fill(0).map(() => Array(numClasses).fill(0));
  
  for (let i = 0; i < trueValues.length; i++) {
    const trueClass = trueValues[i].indexOf(1);
    const predClass = predValues[i].indexOf(Math.max(...predValues[i]));
    matrix[trueClass][predClass]++;
  }
  
  return { matrix, labels };
}

/**
 * Calculate ROC-AUC (simplified for multi-class)
 */
export function calculateROCAUC(
  yTrue: tf.Tensor,
  yPred: tf.Tensor,
  numClasses: number
): number {
  // Simplified ROC-AUC calculation using one-vs-rest approach
  const trueValues = yTrue.arraySync() as number[][];
  const predValues = yPred.arraySync() as number[][];
  
  let totalAUC = 0;
  
  for (let classIdx = 0; classIdx < numClasses; classIdx++) {
    const scores: Array<{ label: number; score: number }> = [];
    
    for (let i = 0; i < trueValues.length; i++) {
      const isPositive = trueValues[i][classIdx] === 1 ? 1 : 0;
      const score = predValues[i][classIdx];
      scores.push({ label: isPositive, score });
    }
    
    // Sort by score descending
    scores.sort((a, b) => b.score - a.score);
    
    // Calculate AUC using trapezoidal rule
    let auc = 0;
    let truePositives = 0;
    let falsePositives = 0;
    let prevTPR = 0;
    let prevFPR = 0;
    
    const positives = scores.filter(s => s.label === 1).length;
    const negatives = scores.filter(s => s.label === 0).length;
    
    if (positives === 0 || negatives === 0) {
      continue; // Skip if no positives or negatives
    }
    
    for (const item of scores) {
      if (item.label === 1) {
        truePositives++;
      } else {
        falsePositives++;
      }
      
      const tpr = truePositives / positives;
      const fpr = falsePositives / negatives;
      
      auc += (fpr - prevFPR) * (tpr + prevTPR) / 2;
      prevTPR = tpr;
      prevFPR = fpr;
    }
    
    totalAUC += auc;
  }
  
  return totalAUC / numClasses;
}

/**
 * Calculate all classification metrics
 */
export function calculateAllMetrics(
  yTrue: tf.Tensor,
  yPred: tf.Tensor,
  labels: string[]
): { metrics: ClassificationMetrics; confusionMatrix: ConfusionMatrix; rocAuc: number } {
  const numClasses = labels.length;
  
  const accuracy = calculateAccuracy(yTrue, yPred);
  const { precision, recall, f1 } = calculatePrecisionRecallF1(yTrue, yPred, numClasses);
  const { macroF1, weightedF1 } = calculateMacroWeightedF1(f1, yTrue);
  const confusionMatrix = generateConfusionMatrix(yTrue, yPred, labels);
  const rocAuc = calculateROCAUC(yTrue, yPred, numClasses);
  
  return {
    metrics: {
      accuracy,
      precision,
      recall,
      f1,
      macroF1,
      weightedF1
    },
    confusionMatrix,
    rocAuc
  };
}

/**
 * Print metrics in a formatted way
 */
export function printMetrics(
  metrics: ClassificationMetrics,
  confusionMatrix: ConfusionMatrix,
  rocAuc: number,
  labels: string[]
): void {
  console.log('\n========== CLASSIFICATION METRICS ==========');
  console.log(`Overall Accuracy: ${(metrics.accuracy * 100).toFixed(2)}%`);
  console.log(`Macro F1: ${(metrics.macroF1 * 100).toFixed(2)}%`);
  console.log(`Weighted F1: ${(metrics.weightedF1 * 100).toFixed(2)}%`);
  console.log(`ROC-AUC: ${(rocAuc * 100).toFixed(2)}%`);
  
  console.log('\n========== PER-CLASS METRICS ==========');
  labels.forEach((label, idx) => {
    console.log(`\n${label}:`);
    console.log(`  Precision: ${(metrics.precision[idx] * 100).toFixed(2)}%`);
    console.log(`  Recall: ${(metrics.recall[idx] * 100).toFixed(2)}%`);
    console.log(`  F1: ${(metrics.f1[idx] * 100).toFixed(2)}%`);
  });
  
  console.log('\n========== CONFUSION MATRIX ==========');
  console.log('Predicted ->');
  console.log('Actual ↓');
  const header = '      ' + labels.map(l => l.substring(0, 6).padEnd(6)).join(' ');
  console.log(header);
  
  confusionMatrix.matrix.forEach((row, idx) => {
    const rowLabel = labels[idx].substring(0, 6).padEnd(6);
    const rowStr = row.map(val => val.toString().padStart(6)).join(' ');
    console.log(`${rowLabel} ${rowStr}`);
  });
}

