import * as tf from '@tensorflow/tfjs';
import { ConsistencyCheckResult } from '../../types';

/**
 * Symptom Consistency ANN
 * Binary classifier to detect manipulated/inconsistent symptoms
 * Output: [consistency_score, manipulation_score, warning_score]
 */
export class ConsistencyCheckerModel {
  private model: tf.LayersModel | null = null;
  private isInitialized = false;
  private inputSize: number;

  constructor(inputSize: number = 52) {
    this.inputSize = inputSize;
  }

  /**
   * Create the model architecture
   */
  createModel(): tf.LayersModel {
    const model = tf.sequential({
      layers: [
        tf.layers.dense({
          inputShape: [this.inputSize],
          units: 64,
          activation: 'relu',
          name: 'dense_1'
        }),
        tf.layers.dropout({
          rate: 0.3,
          name: 'dropout_1'
        }),
        tf.layers.dense({
          units: 32,
          activation: 'relu',
          name: 'dense_2'
        }),
        tf.layers.dense({
          units: 3, // [consistency_score, manipulation_score, warning_score]
          activation: 'sigmoid',
          name: 'output'
        })
      ]
    });

    model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'meanSquaredError',
      metrics: ['accuracy']
    });

    return model;
  }

  /**
   * Initialize or create the model
   */
  async initialize(): Promise<void> {
    if (this.isInitialized && this.model) {
      return;
    }

    this.model = this.createModel();
    this.isInitialized = true;
  }

  /**
   * Load model from file
   * Note: file:// protocol doesn't work with @tensorflow/tfjs in Node.js
   * Models will be initialized fresh each time
   */
  async loadModel(modelPath: string): Promise<void> {
    // Skip file loading - TensorFlow.js browser version doesn't support file:// in Node.js
    // Models will be initialized fresh (untrained, but functional)
    console.log(`Note: Model loading from file not supported with @tensorflow/tfjs. Initializing new model.`);
    await this.initialize();
  }

  /**
   * Save model to file
   * Note: file:// protocol doesn't work with @tensorflow/tfjs in Node.js
   * Models cannot be saved with the browser version of TensorFlow.js
   */
  async saveModel(modelPath: string): Promise<void> {
    if (!this.model) {
      throw new Error('Model not initialized');
    }
    // Skip saving - TensorFlow.js browser version doesn't support file:// in Node.js
    console.log(`Note: Model saving not supported with @tensorflow/tfjs. Model will be retrained on next run.`);
    console.log(`Model architecture and weights are in memory only.`);
  }

  /**
   * Check symptom consistency
   */
  async checkConsistency(features: number[], symptoms: string[], severities: Record<string, number>): Promise<ConsistencyCheckResult> {
    await this.initialize();

    if (!this.model) {
      throw new Error('Model not initialized');
    }

    const tensor = tf.tensor2d([features]);
    const prediction = this.model.predict(tensor) as tf.Tensor;
    const values = await prediction.data();
    prediction.dispose();
    tensor.dispose();

    const consistencyScore = values[0];
    const manipulationScore = values[1];
    const warningScore = values[2];

    const warnings: string[] = [];
    let isManipulated = false;

    // Rule-based checks - STRONG DETECTION
    const symptomSet = new Set(symptoms.map(s => s.toLowerCase()));
    const symptomCount = symptoms.length;
    const activeSymptomCount = features.slice(0, 50).filter(f => f > 0).length;

    // ========== CRITICAL: Too many symptoms ==========
    if (symptomCount > 25) {
      warnings.push(`Too many symptoms selected (${symptomCount}). This is medically unrealistic.`);
      isManipulated = true;
    } else if (symptomCount > 20) {
      warnings.push(`Very high number of symptoms (${symptomCount}). This may indicate manipulation.`);
      isManipulated = true;
    } else if (symptomCount > 15) {
      warnings.push(`High number of symptoms (${symptomCount}). Please verify all symptoms are accurate.`);
    }

    // Check active symptom count in feature vector
    if (activeSymptomCount > 25) {
      warnings.push(`Unrealistic symptom combination detected (${activeSymptomCount} active symptoms)`);
      isManipulated = true;
    }

    // ========== Check for contradictions ==========
    if (symptomSet.has('diarrhea') && symptomSet.has('constipation')) {
      warnings.push('Contradictory symptoms: diarrhea and constipation cannot occur simultaneously');
      isManipulated = true;
    }

    // ========== Check for medically impossible combinations ==========
    // Respiratory + UTI symptoms together (unlikely)
    const hasRespiratory = symptomSet.has('cough') || symptomSet.has('runny_nose') || symptomSet.has('sneezing');
    const hasUTI = symptomSet.has('burning_urination') || symptomSet.has('frequent_urination');
    if (hasRespiratory && hasUTI && symptomCount > 10) {
      warnings.push('Unusual combination: respiratory and urinary symptoms together may indicate separate conditions');
    }

    // Fever + Allergy (allergies don't cause fever)
    if (symptomSet.has('fever') && symptomSet.has('sneezing') && symptomSet.has('itchy_eyes') && !symptomSet.has('cough')) {
      warnings.push('Fever with allergy symptoms is unusual - allergies typically do not cause fever');
    }

    // ========== Check for unrealistic severity patterns ==========
    const severitiesList = Object.values(severities);
    if (severitiesList.length > 0) {
      const maxSeverity = Math.max(...severitiesList);
      const minSeverity = Math.min(...severitiesList);
      const avgSeverity = severitiesList.reduce((a, b) => a + b, 0) / severitiesList.length;

      // Unrealistic patterns
      if (maxSeverity > 9 && avgSeverity < 2 && severitiesList.length > 3) {
        warnings.push('Unrealistic severity distribution: very high max but very low average');
        isManipulated = true;
      }

      // All symptoms at maximum severity
      if (severitiesList.length > 5 && severitiesList.every(s => s >= 9)) {
        warnings.push('All symptoms at maximum severity is medically unlikely');
        isManipulated = true;
      }
    }

    // ========== Check symptom diversity (too many different systems) ==========
    const hasRespiratorySymptoms = symptomSet.has('cough') || symptomSet.has('runny_nose') || symptomSet.has('sneezing') || symptomSet.has('shortness_of_breath');
    const hasGISymptoms = symptomSet.has('nausea') || symptomSet.has('vomiting') || symptomSet.has('diarrhea') || symptomSet.has('stomach_pain');
    const hasUrinarySymptoms = symptomSet.has('burning_urination') || symptomSet.has('frequent_urination');
    const hasNeurologicalSymptoms = symptomSet.has('headache') || symptomSet.has('dizziness') || symptomSet.has('confusion');
    const hasPsychologicalSymptoms = symptomSet.has('anxiety') || symptomSet.has('irritability') || symptomSet.has('restlessness');

    const systemCount = [hasRespiratorySymptoms, hasGISymptoms, hasUrinarySymptoms, hasNeurologicalSymptoms, hasPsychologicalSymptoms]
      .filter(Boolean).length;

    if (systemCount >= 4 && symptomCount > 12) {
      warnings.push(`Symptoms affecting ${systemCount} different body systems simultaneously is highly unusual`);
      isManipulated = true;
    }

    // ========== Model-based detection ==========
    // Lower threshold for manipulation detection
    if (manipulationScore > 0.5) {
      isManipulated = true;
      if (manipulationScore > 0.7) {
        warnings.push('High manipulation score detected by AI model');
      }
    }

    // ========== Warning score ==========
    if (warningScore > 0.6) {
      warnings.push('Multiple warning indicators detected');
      if (warningScore > 0.8) {
        isManipulated = true;
      }
    }

    // ========== Final manipulation check ==========
    // If too many warnings or suspicious patterns, mark as manipulated
    if (warnings.length > 3 || (symptomCount > 20 && warnings.length > 1)) {
      isManipulated = true;
    }

    // ========== Adjust consistency score ==========
    // Penalize heavily for too many symptoms
    let adjustedScore = consistencyScore;
    if (symptomCount > 25) {
      adjustedScore = Math.max(0, adjustedScore - 0.5);
    } else if (symptomCount > 20) {
      adjustedScore = Math.max(0, adjustedScore - 0.3);
    } else if (symptomCount > 15) {
      adjustedScore = Math.max(0, adjustedScore - 0.2);
    }
    
    // Additional penalty for warnings
    adjustedScore = Math.max(0, adjustedScore - (warnings.length * 0.15));

    return {
      consistencyScore: adjustedScore,
      warnings,
      isManipulated
    };
  }

  /**
   * Get model instance
   */
  getModel(): tf.LayersModel | null {
    return this.model;
  }
}

