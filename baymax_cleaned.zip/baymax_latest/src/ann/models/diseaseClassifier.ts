import * as tf from '@tensorflow/tfjs';
import { DiseaseProbabilities } from '../../types';
import { DISEASE_CLASSES } from '../preprocess';

/**
 * Disease Classifier ANN with exact architecture specification
 * Input: 45 features (can be adjusted)
 * Output: softmax(10 diseases)
 * Architecture:
 *   Dense(128, relu)
 *   Dense(64, relu)
 *   Dropout(0.25)
 *   Dense(32, relu)
 *   Dense(10, softmax)
 */
export class DiseaseClassifierModel {
  private model: tf.LayersModel | null = null;
  private isInitialized = false;
  private inputSize: number;

  constructor(inputSize: number = 52) {
    this.inputSize = inputSize;
  }

  /**
   * Create the model architecture
   */
  createModel(): tf.LayersModel {
    const model = tf.sequential({
      layers: [
        tf.layers.dense({
          inputShape: [this.inputSize],
          units: 128,
          activation: 'relu',
          kernelRegularizer: tf.regularizers.l2({ l2: 0.001 }), // L2 regularization
          name: 'dense_1'
        }),
        tf.layers.dropout({
          rate: 0.3, // Increased dropout
          name: 'dropout_1'
        }),
        tf.layers.dense({
          units: 64,
          activation: 'relu',
          kernelRegularizer: tf.regularizers.l2({ l2: 0.001 }), // L2 regularization
          name: 'dense_2'
        }),
        tf.layers.dropout({
          rate: 0.4, // Increased dropout
          name: 'dropout_2'
        }),
        tf.layers.dense({
          units: 32,
          activation: 'relu',
          kernelRegularizer: tf.regularizers.l2({ l2: 0.001 }), // L2 regularization
          name: 'dense_3'
        }),
        tf.layers.dropout({
          rate: 0.3, // Additional dropout
          name: 'dropout_3'
        }),
        tf.layers.dense({
          units: DISEASE_CLASSES.length,
          activation: 'softmax',
          name: 'output'
        })
      ]
    });

    // Use lower learning rate and add L2 regularization to prevent overfitting
    model.compile({
      optimizer: tf.train.adam(0.0005), // Reduced from 0.001
      loss: 'categoricalCrossentropy',
      metrics: ['accuracy']
    });

    return model;
  }

  /**
   * Initialize or create the model
   */
  async initialize(): Promise<void> {
    if (this.isInitialized && this.model) {
      return;
    }

    this.model = this.createModel();
    this.isInitialized = true;
  }

  /**
   * Load model from file
   * Note: file:// protocol doesn't work with @tensorflow/tfjs in Node.js
   * Models will be initialized fresh each time
   */
  async loadModel(modelPath: string): Promise<void> {
    // Skip file loading - TensorFlow.js browser version doesn't support file:// in Node.js
    // Models will be initialized fresh (untrained, but functional)
    console.log(`Note: Model loading from file not supported with @tensorflow/tfjs. Initializing new model.`);
    await this.initialize();
  }

  /**
   * Save model to file
   * Note: file:// protocol doesn't work with @tensorflow/tfjs in Node.js
   * Models cannot be saved with the browser version of TensorFlow.js
   */
  async saveModel(modelPath: string): Promise<void> {
    if (!this.model) {
      throw new Error('Model not initialized');
    }
    // Skip saving - TensorFlow.js browser version doesn't support file:// in Node.js
    console.log(`Note: Model saving not supported with @tensorflow/tfjs. Model will be retrained on next run.`);
    console.log(`Model architecture and weights are in memory only.`);
  }

  /**
   * Predict disease probabilities
   */
  async predict(features: number[]): Promise<{
    probabilities: DiseaseProbabilities;
    severity: number;
    confidence: number;
  }> {
    await this.initialize();

    if (!this.model) {
      throw new Error('Model not initialized');
    }

    const tensor = tf.tensor2d([features]);
    const prediction = this.model.predict(tensor) as tf.Tensor;
    const values = await prediction.data();
    prediction.dispose();
    tensor.dispose();

    const probs = Array.from(values);
    const maxProb = Math.max(...probs);
    const sum = probs.reduce((a, b) => a + b, 0);
    const normalized = probs.map(p => p / sum);

    const diseaseProbabilities: DiseaseProbabilities = {
      flu: normalized[0],
      cold: normalized[1],
      covid: normalized[2],
      allergy: normalized[3],
      migraine: normalized[4],
      stomach_infection: normalized[5],
      uti: normalized[6],
      dehydration: normalized[7],
      anxiety: normalized[8],
      food_poisoning: normalized[9]
    };

    // Calculate severity (0-100) based on probabilities
    const severity = maxProb * 100;

    // Calculate confidence
    const entropy = -normalized.reduce((sum, p) => sum + (p > 0 ? p * Math.log2(p) : 0), 0);
    const maxEntropy = Math.log2(DISEASE_CLASSES.length);
    const confidence = maxProb * (1 - entropy / maxEntropy) * 100;

    return {
      probabilities: diseaseProbabilities,
      severity: Math.round(severity),
      confidence: Math.round(confidence)
    };
  }

  /**
   * Get model instance
   */
  getModel(): tf.LayersModel | null {
    return this.model;
  }

  /**
   * Get model summary
   */
  getSummary(): void {
    if (this.model) {
      this.model.summary();
    }
  }
}

