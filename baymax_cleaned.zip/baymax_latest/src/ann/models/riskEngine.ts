import * as tf from '@tensorflow/tfjs';
import { RiskEngineOutput } from '../../types';

/**
 * Risk Engine ANN
 * Predicts:
 *   - riskLevel (0/1/2 for low/medium/high)
 *   - emergencyScore (0-1)
 *   - progressionScore (0-1)
 */
export class RiskEngineModel {
  private model: tf.LayersModel | null = null;
  private isInitialized = false;
  private inputSize: number;

  constructor(inputSize: number = 52) {
    this.inputSize = inputSize;
  }

  /**
   * Create the model architecture
   */
  createModel(): tf.LayersModel {
    const model = tf.sequential({
      layers: [
        tf.layers.dense({
          inputShape: [this.inputSize],
          units: 96,
          activation: 'relu',
          name: 'dense_1'
        }),
        tf.layers.dropout({
          rate: 0.3,
          name: 'dropout_1'
        }),
        tf.layers.dense({
          units: 48,
          activation: 'relu',
          name: 'dense_2'
        }),
        tf.layers.dense({
          units: 24,
          activation: 'relu',
          name: 'dense_3'
        }),
        tf.layers.dense({
          units: 5, // [riskLevel, emergencyScore, progressionScore, dehydrationRisk, infectionSpread]
          activation: 'sigmoid',
          name: 'output'
        })
      ]
    });

    model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'meanSquaredError',
      metrics: ['accuracy']
    });

    return model;
  }

  /**
   * Initialize or create the model
   */
  async initialize(): Promise<void> {
    if (this.isInitialized && this.model) {
      return;
    }

    this.model = this.createModel();
    this.isInitialized = true;
  }

  /**
   * Load model from file
   * Note: file:// protocol doesn't work with @tensorflow/tfjs in Node.js
   * Models will be initialized fresh each time
   */
  async loadModel(modelPath: string): Promise<void> {
    // Skip file loading - TensorFlow.js browser version doesn't support file:// in Node.js
    // Models will be initialized fresh (untrained, but functional)
    console.log(`Note: Model loading from file not supported with @tensorflow/tfjs. Initializing new model.`);
    await this.initialize();
  }

  /**
   * Save model to file
   * Note: file:// protocol doesn't work with @tensorflow/tfjs in Node.js
   * Models cannot be saved with the browser version of TensorFlow.js
   */
  async saveModel(modelPath: string): Promise<void> {
    if (!this.model) {
      throw new Error('Model not initialized');
    }
    // Skip saving - TensorFlow.js browser version doesn't support file:// in Node.js
    console.log(`Note: Model saving not supported with @tensorflow/tfjs. Model will be retrained on next run.`);
    console.log(`Model architecture and weights are in memory only.`);
  }

  /**
   * Predict risk levels
   */
  async predict(features: number[]): Promise<RiskEngineOutput> {
    await this.initialize();

    if (!this.model) {
      throw new Error('Model not initialized');
    }

    const tensor = tf.tensor2d([features]);
    const prediction = this.model.predict(tensor) as tf.Tensor;
    const values = await prediction.data();
    prediction.dispose();
    tensor.dispose();

    const riskLevelRaw = values[0];
    const emergencyScoreRaw = values[1];
    const progressionScoreRaw = values[2];
    const dehydrationRisk = values[3];
    const infectionSpreadRisk = values[4];

    // Convert risk level (0-1) to categorical
    let riskLevel: "low" | "medium" | "high";
    if (riskLevelRaw < 0.33) {
      riskLevel = "low";
    } else if (riskLevelRaw < 0.67) {
      riskLevel = "medium";
    } else {
      riskLevel = "high";
    }

    // Scale scores to 0-100
    const emergencyScore = Math.min(100, Math.round(emergencyScoreRaw * 100));
    const progressionScore = Math.min(100, Math.round(progressionScoreRaw * 100));

    return {
      riskLevel,
      emergencyScore,
      progressionScore
    };
  }

  /**
   * Get model instance
   */
  getModel(): tf.LayersModel | null {
    return this.model;
  }
}

