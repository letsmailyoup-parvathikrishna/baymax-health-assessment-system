import * as tf from '@tensorflow/tfjs';
import { UserSymptomInput } from '../types';

// Common symptom vocabulary - matches dataset and common medical symptoms
// Note: This is used for feature vector mapping, symptoms can be any string
export const SYMPTOM_VOCAB = [
  'fever', 'cough', 'runny_nose', 'sore_throat', 'headache',
  'body_ache', 'fatigue', 'loss_of_smell', 'loss_of_taste',
  'nausea', 'vomiting', 'diarrhea', 'stomach_cramps', 'chest_pain',
  'difficulty_breathing', 'shortness_of_breath', 'dizziness', 
  'rapid_heartbeat', 'chills', 'rash', 'itchy_skin', 'joint_pain',
  'burning_urination', 'frequent_urination', 'lower_abdominal_pain',
  'bloating', 'gas', 'dehydration_signs', 'dry_mouth',
  'sensitivity_to_light', 'anxiety', 'restlessness', 'trembling',
  'sweating', 'irritability', 'trouble_sleeping', 'appetite_loss',
  'weight_loss', 'weight_gain', 'throat_itchiness', 'congestion',
  'wheezing', 'sneezing', 'itchy_eyes', 'stomach_pain', 
  'abdominal_cramps', 'back_pain', 'sore_muscles', 'thirst',
  'confusion'
];

export const DISEASE_CLASSES = [
  'flu', 'cold', 'covid', 'allergy', 'migraine',
  'stomach_infection', 'uti', 'dehydration', 'anxiety', 'food_poisoning'
];

/**
 * Convert symptom input to feature vector
 */
export function symptomsToVector(input: UserSymptomInput): number[] {
  const vector = new Array(SYMPTOM_VOCAB.length).fill(0);
  
  input.symptoms.forEach(symptom => {
    const index = SYMPTOM_VOCAB.indexOf(symptom.toLowerCase());
    if (index !== -1) {
      // Use severity if available, otherwise 1.0
      const severity = input.severity[symptom] || 1.0;
      vector[index] = Math.min(severity / 10.0, 1.0); // Normalize to 0-1
    }
  });
  
  // Add metadata features (duration, age)
  const durationNormalized = Math.min(input.duration / 168.0, 1.0); // Normalize to 1 week
  const ageNormalized = input.age ? Math.min(input.age / 100.0, 1.0) : 0.5;
  
  const result = [...vector, durationNormalized, ageNormalized];
  
  // Ensure exactly 52 features (50 symptoms + 2 metadata)
  if (result.length !== 52) {
    console.warn(`Feature vector size mismatch: expected 52, got ${result.length}. Truncating/padding.`);
    if (result.length > 52) {
      return result.slice(0, 52);
    } else {
      return [...result, ...new Array(52 - result.length).fill(0)];
    }
  }
  
  return result;
}

/**
 * Create tensor from feature vector
 */
export function createInputTensor(features: number[]): tf.Tensor2D {
  return tf.tensor2d([features]);
}

/**
 * Normalize probabilities to sum to 1
 */
export function normalizeProbabilities(probs: number[]): number[] {
  const sum = probs.reduce((a, b) => a + b, 0);
  if (sum === 0) return probs.map(() => 1 / probs.length);
  return probs.map(p => p / sum);
}

/**
 * Min-max normalization
 */
export function minMaxNormalize(data: number[], min?: number, max?: number): number[] {
  const dataMin = min !== undefined ? min : Math.min(...data);
  const dataMax = max !== undefined ? max : Math.max(...data);
  const range = dataMax - dataMin;
  
  if (range === 0) return data.map(() => 0.5);
  
  return data.map(val => (val - dataMin) / range);
}

/**
 * One-hot encode disease labels
 */
export function oneHotEncode(labels: string[], classes: string[]): number[][] {
  return labels.map(label => {
    const index = classes.indexOf(label);
    const encoded = new Array(classes.length).fill(0);
    if (index !== -1) {
      encoded[index] = 1;
    }
    return encoded;
  });
}

/**
 * Train-test split
 */
export function trainTestSplit<T>(data: T[], testSize: number = 0.2): { train: T[]; test: T[] } {
  const shuffled = [...data].sort(() => Math.random() - 0.5);
  const splitIndex = Math.floor(shuffled.length * (1 - testSize));
  return {
    train: shuffled.slice(0, splitIndex),
    test: shuffled.slice(splitIndex)
  };
}

/**
 * Create batches from data
 */
export function createBatches<T>(data: T[], batchSize: number): T[][] {
  const batches: T[][] = [];
  for (let i = 0; i < data.length; i += batchSize) {
    batches.push(data.slice(i, i + batchSize));
  }
  return batches;
}

