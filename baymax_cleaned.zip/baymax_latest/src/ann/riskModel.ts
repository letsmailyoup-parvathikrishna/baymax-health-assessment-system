import * as tf from '@tensorflow/tfjs';
import { UserSymptomInput, RiskEngineOutput } from '../types';
import { symptomsToVector, createInputTensor } from './preprocess';

export class RiskPredictionModel {
  private model: tf.LayersModel | null = null;
  private isInitialized = false;

  /**
   * Initialize or create the risk prediction model
   */
  async initialize(): Promise<void> {
    if (this.isInitialized && this.model) {
      return;
    }

    // Create network for risk assessment
    this.model = tf.sequential({
      layers: [
        tf.layers.dense({
          inputShape: [52], // SYMPTOM_VOCAB.length (50) + 2 metadata
          units: 96,
          activation: 'relu',
          name: 'hidden1'
        }),
        tf.layers.dropout({ rate: 0.3 }),
        tf.layers.dense({
          units: 48,
          activation: 'relu',
          name: 'hidden2'
        }),
        tf.layers.dense({
          units: 24,
          activation: 'relu',
          name: 'hidden3'
        }),
        tf.layers.dense({
          units: 5, // [worsening, urgent_care, dehydration, fever_onset, infection_spread]
          activation: 'sigmoid',
          name: 'output'
        })
      ]
    });

    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'meanSquaredError',
      metrics: ['accuracy']
    });

    this.isInitialized = true;
  }

  /**
   * Predict risk levels
   */
  async predict(input: UserSymptomInput): Promise<RiskEngineOutput> {
    await this.initialize();

    if (!this.model) {
      throw new Error('Model not initialized');
    }

    const features = symptomsToVector(input);
    const tensor = createInputTensor(features);
    
    const prediction = this.model.predict(tensor) as tf.Tensor;
    const values = await prediction.data();
    prediction.dispose();
    tensor.dispose();

    const worseningLikelihood = values[0];
    const urgentCareRisk = values[1];
    const dehydrationRisk = values[2];
    const feverOnsetRisk = values[3];
    const infectionSpreadRisk = values[4];

    // Calculate emergency score (0-100)
    let emergencyScore = Math.min(100, (
      urgentCareRisk * 40 +
      worseningLikelihood * 30 +
      infectionSpreadRisk * 20 +
      feverOnsetRisk * 10
    ) * 100);

    // Calculate progression score (0-100)
    const progressionScore = Math.min(100, (
      worseningLikelihood * 50 +
      infectionSpreadRisk * 30 +
      feverOnsetRisk * 20
    ) * 100);

    // Determine risk level
    let riskLevel: "low" | "medium" | "high";
    if (emergencyScore < 30) {
      riskLevel = "low";
    } else if (emergencyScore < 70) {
      riskLevel = "medium";
    } else {
      riskLevel = "high";
    }

    // Rule-based adjustments
    const symptomSet = new Set(input.symptoms.map(s => s.toLowerCase()));
    
    // High-risk indicators
    if (symptomSet.has('chest_pain') || symptomSet.has('shortness_of_breath')) {
      emergencyScore = Math.min(100, emergencyScore + 20);
      if (riskLevel === "low") riskLevel = "medium";
      if (riskLevel === "medium") riskLevel = "high";
    }

    if (symptomSet.has('fever') && input.severity['fever'] > 7) {
      emergencyScore = Math.min(100, emergencyScore + 15);
    }

    if (symptomSet.has('vomiting') && symptomSet.has('diarrhea')) {
      emergencyScore = Math.min(100, emergencyScore + 10);
    }

    return {
      riskLevel,
      emergencyScore: Math.round(emergencyScore),
      progressionScore: Math.round(progressionScore)
    };
  }

  /**
   * Get model summary
   */
  getModel(): tf.LayersModel | null {
    return this.model;
  }
}

