import * as fs from 'fs';
import * as path from 'path';
import { DISEASE_CLASSES } from '../preprocess';

export interface DatasetRow {
  symptoms: number[];
  age: number;
  gender: number;
  stressLevel: number;
  sleepHours: number;
  waterIntake: number;
  label: string;
}

/**
 * Load and parse the CSV dataset
 */
export function loadDataset(filePath: string): DatasetRow[] {
  const fullPath = path.resolve(filePath);
  const content = fs.readFileSync(fullPath, 'utf-8');
  const lines = content.trim().split('\n');
  
  // Skip header
  const dataLines = lines.slice(1);
  
  const dataset: DatasetRow[] = [];
  
  for (const line of dataLines) {
    if (!line.trim()) continue;
    
    // Handle CSV with proper parsing (handles quoted values)
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    values.push(current.trim()); // Add last value
    
    if (values.length < 45) continue; // Skip incomplete rows
    
    // Extract symptom columns (first 39 columns are symptoms)
    const symptoms = values.slice(0, 39).map(v => parseInt(v.trim()) || 0);
    
    // Extract metadata
    const age = parseFloat(values[39]) || 0;
    const gender = parseInt(values[40]) || 0;
    const stressLevel = parseFloat(values[41]) || 0;
    const sleepHours = parseFloat(values[42]) || 0;
    const waterIntake = parseFloat(values[43]) || 0;
    const label = values[44]?.trim() || '';
    
    dataset.push({
      symptoms,
      age,
      gender,
      stressLevel,
      sleepHours,
      waterIntake,
      label
    });
  }
  
  return dataset;
}

/**
 * Map dataset labels to our disease classes
 */
export function mapLabelToDiseaseClass(label: string): number {
  const labelMap: Record<string, number> = {
    'flu': 0,
    'common_cold': 1,  // Maps to 'cold' in our classes
    'cold': 1,
    'covid': 2,
    'allergy': 3,
    'migraine': 4,
    'stomach_infection': 5,
    'urinary_infection': 6,  // Maps to 'uti' in our classes
    'uti': 6,
    'dehydration': 7,
    'anxiety_attack': 8,  // Maps to 'anxiety' in our classes
    'anxiety': 8,
    'food_poisoning': 9
  };
  
  // Normalize label
  const normalizedLabel = label.toLowerCase().replace(/\s+/g, '_');
  
  return labelMap[normalizedLabel] ?? 0; // Default to flu if unknown
}

/**
 * Convert dataset row to feature vector matching our preprocessing
 */
export function rowToFeatureVector(row: DatasetRow): number[] {
  // Map dataset symptoms (39) to our vocabulary (50 symptoms)
  // Dataset order matches the CSV header exactly
  const datasetToVocab: (number | null)[] = [
    0,   // fever -> fever
    1,   // cough -> cough
    2,   // runny_nose -> runny_nose
    3,   // sore_throat -> runny_nose
    4,   // headache -> headache
    5,   // body_ache -> body_ache
    6,   // fatigue -> fatigue
    7,   // loss_of_smell -> loss_of_smell
    8,   // loss_of_taste -> loss_of_taste
    9,   // nausea -> nausea
    10,  // vomiting -> vomiting
    11,  // diarrhea -> diarrhea
    12,  // stomach_cramps -> stomach_cramps
    13,  // chest_pain -> chest_pain
    14,  // difficulty_breathing -> difficulty_breathing
    16,  // dizziness -> dizziness
    17,  // rapid_heartbeat -> rapid_heartbeat
    18,  // chills -> chills
    19,  // rash -> rash
    20,  // itchy_skin -> itchy_skin
    21,  // joint_pain -> joint_pain
    22,  // burning_urination -> burning_urination
    23,  // frequent_urination -> frequent_urination
    24,  // lower_abdominal_pain -> lower_abdominal_pain
    25,  // bloating -> bloating
    26,  // gas -> gas
    27,  // dehydration_signs -> dehydration_signs
    28,  // dry_mouth -> dry_mouth
    29,  // sensitivity_to_light -> sensitivity_to_light
    30,  // anxiety -> anxiety
    31,  // restlessness -> restlessness
    32,  // trembling -> trembling
    33,  // sweating -> sweating
    34,  // irritability -> irritability
    35,  // trouble_sleeping -> trouble_sleeping
    36,  // appetite_loss -> appetite_loss
    37,  // weight_loss -> weight_loss
    38,  // weight_gain -> weight_gain
    39,  // throat_itchiness -> throat_itchiness
  ];
  
  const features = new Array(50).fill(0); // Our vocabulary has 50 symptoms
  
  // Map dataset symptoms to our vocabulary
  for (let i = 0; i < Math.min(row.symptoms.length, datasetToVocab.length); i++) {
    const vocabIndex = datasetToVocab[i];
    if (vocabIndex !== null && vocabIndex !== undefined && vocabIndex < features.length) {
      features[vocabIndex] = row.symptoms[i] || 0;
    }
  }
  
  // Add metadata features
  const durationNormalized = 24 / 168.0; // Assume 24 hours (we don't have duration in dataset)
  const ageNormalized = Math.min(row.age / 100.0, 1.0);
  
  features.push(durationNormalized);
  features.push(ageNormalized);
  
  return features;
}

/**
 * Prepare training data from dataset
 */
export function prepareTrainingData(dataset: DatasetRow[]): {
  xs: number[][];
  ys: number[][];
} {
  const xs: number[][] = [];
  const ys: number[][] = [];
  
  for (const row of dataset) {
    const features = rowToFeatureVector(row);
    const diseaseClass = mapLabelToDiseaseClass(row.label);
    
    // One-hot encode the label
    const oneHot = new Array(DISEASE_CLASSES.length).fill(0);
    oneHot[diseaseClass] = 1;
    
    xs.push(features);
    ys.push(oneHot);
  }
  
  return { xs, ys };
}

/**
 * Prepare consistency training data with improved manipulation detection
 */
export function prepareConsistencyData(dataset: DatasetRow[]): {
  xs: number[][];
  ys: number[][];
} {
  const xs: number[][] = [];
  const ys: number[][] = [];
  
  for (const row of dataset) {
    const features = rowToFeatureVector(row);
    const symptomCount = row.symptoms.filter(s => s === 1).length;
    const activeSymptomCount = features.slice(0, 50).filter(f => f > 0).length;
    
    // ========== Consistency Score ==========
    // Realistic: 3-12 symptoms (score 0.7-1.0)
    // Suspicious: 13-20 symptoms (score 0.4-0.7)
    // Manipulated: >20 symptoms (score 0.0-0.4)
    const isManipulatedLabel = row.label === 'manipulated' || row.label === 'inconsistent';
    
    let consistencyScore: number;
    if (isManipulatedLabel) {
      // Explicitly labeled as manipulated - low consistency
      consistencyScore = Math.random() * 0.3; // 0.0-0.3
    } else if (symptomCount <= 12) {
      consistencyScore = 0.7 + (12 - symptomCount) * 0.025; // 0.7-1.0
    } else if (symptomCount <= 20) {
      consistencyScore = 0.4 + (20 - symptomCount) * 0.043; // 0.4-0.7
    } else {
      consistencyScore = Math.max(0, 0.4 - (symptomCount - 20) * 0.02); // 0.0-0.4
    }
    consistencyScore = Math.min(1, Math.max(0, consistencyScore));
    
    // ========== Manipulation Score ==========
    // Higher score = more likely manipulated
    let manipulationScore: number;
    if (symptomCount <= 10) {
      manipulationScore = 0.05 + Math.random() * 0.1; // 0.05-0.15 (normal variation)
    } else if (symptomCount <= 15) {
      manipulationScore = 0.2 + (symptomCount - 10) * 0.08; // 0.2-0.6
    } else if (symptomCount <= 20) {
      manipulationScore = 0.6 + (symptomCount - 15) * 0.06; // 0.6-0.9
    } else {
      manipulationScore = 0.9 + Math.min(0.1, (symptomCount - 20) * 0.01); // 0.9-1.0
    }
    manipulationScore = Math.min(1, Math.max(0, manipulationScore));
    
    // Check for contradictions
    const hasDiarrhea = row.symptoms[11] === 1;
    const hasConstipation = false; // Not in dataset, but check if we can infer
    if (hasDiarrhea && symptomCount > 15) {
      manipulationScore = Math.min(1, manipulationScore + 0.2);
    }
    
    // Check symptom system diversity (too many different systems = suspicious)
    const hasRespiratory = row.symptoms[1] === 1 || row.symptoms[2] === 1; // cough, runny_nose
    const hasGI = row.symptoms[9] === 1 || row.symptoms[10] === 1 || row.symptoms[11] === 1; // nausea, vomiting, diarrhea
    const hasUrinary = row.symptoms[21] === 1 || row.symptoms[22] === 1; // burning_urination, frequent_urination
    const hasNeurological = row.symptoms[4] === 1 || row.symptoms[15] === 1; // headache, dizziness
    const hasPsychological = row.symptoms[29] === 1 || row.symptoms[33] === 1; // anxiety, irritability
    
    const systemCount = [hasRespiratory, hasGI, hasUrinary, hasNeurological, hasPsychological]
      .filter(Boolean).length;
    
    if (systemCount >= 4 && symptomCount > 12) {
      manipulationScore = Math.min(1, manipulationScore + 0.3);
    }
    
    // ========== Warning Score ==========
    let warningScore: number;
    if (isManipulatedLabel) {
      // Explicitly labeled as manipulated - high warning
      warningScore = 0.8 + Math.random() * 0.2; // 0.8-1.0
    } else if (symptomCount <= 10) {
      warningScore = 0.05 + Math.random() * 0.1;
    } else if (symptomCount <= 15) {
      warningScore = 0.3 + (symptomCount - 10) * 0.08; // 0.3-0.7
    } else if (symptomCount <= 20) {
      warningScore = 0.7 + (symptomCount - 15) * 0.04; // 0.7-0.9
    } else {
      warningScore = 0.9 + Math.min(0.1, (symptomCount - 20) * 0.01); // 0.9-1.0
    }
    
    // Add warnings for contradictions
    if (hasDiarrhea && symptomCount > 15) {
      warningScore = Math.min(1, warningScore + 0.2);
    }
    
    // High warning for multiple systems
    if (systemCount >= 4 && symptomCount > 12) {
      warningScore = Math.min(1, warningScore + 0.3);
    }
    
    warningScore = Math.min(1, Math.max(0, warningScore));
    
    xs.push(features);
    ys.push([consistencyScore, manipulationScore, warningScore]);
  }
  
  return { xs, ys };
}

/**
 * Prepare risk training data
 */
export function prepareRiskData(dataset: DatasetRow[]): {
  xs: number[][];
  ys: number[][];
} {
  const xs: number[][] = [];
  const ys: number[][] = [];
  
  for (const row of dataset) {
    const features = rowToFeatureVector(row);
    
    // Calculate risk scores based on symptoms and metadata
    const hasChestPain = row.symptoms[13] === 1; // chest_pain
    const hasDifficultyBreathing = row.symptoms[14] === 1;
    const hasFever = row.symptoms[0] === 1;
    const hasVomiting = row.symptoms[10] === 1;
    const hasDiarrhea = row.symptoms[11] === 1;
    
    const worseningLikelihood = (hasChestPain || hasDifficultyBreathing) ? 0.8 : 0.3;
    const urgentCareRisk = (hasChestPain || hasDifficultyBreathing || (hasFever && row.age > 65)) ? 0.7 : 0.2;
    const dehydrationRisk = (hasVomiting && hasDiarrhea && row.waterIntake < 2) ? 0.8 : 0.2;
    const feverOnsetRisk = hasFever ? 0.6 : 0.1;
    const infectionSpreadRisk = (hasFever && row.symptoms[1] === 1) ? 0.7 : 0.2; // fever + cough
    
    xs.push(features);
    ys.push([
      worseningLikelihood,
      urgentCareRisk,
      dehydrationRisk,
      feverOnsetRisk,
      infectionSpreadRisk
    ]);
  }
  
  return { xs, ys };
}

