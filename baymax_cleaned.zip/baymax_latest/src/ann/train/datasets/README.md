# Training Datasets

This directory contains the training dataset for the ANN models.

## Datasets

**baymax_medical_dataset_v2_5000.csv** - Large medical dataset with 5000 samples (PRIORITY - used first if available)

**baymax_dataset.csv** - Medical dataset with 1000 samples (fallback)

### Dataset Format

The dataset contains:
- **39 symptom columns** (binary 0/1): fever, cough, runny_nose, sore_throat, headache, body_ache, fatigue, loss_of_smell, loss_of_taste, nausea, vomiting, diarrhea, stomach_cramps, chest_pain, difficulty_breathing, dizziness, rapid_heartbeat, chills, rash, itchy_skin, joint_pain, burning_urination, frequent_urination, lower_abdominal_pain, bloating, gas, dehydration_signs, dry_mouth, sensitivity_to_light, anxiety, restlessness, trembling, sweating, irritability, trouble_sleeping, appetite_loss, weight_loss, weight_gain, throat_itchiness
- **Metadata columns**: age, gender, stress_level, sleep_hours, water_intake
- **Label column**: Disease classification (flu, common_cold, covid, allergy, migraine, stomach_infection, urinary_infection, dehydration, anxiety_attack, food_poisoning)

### Data Processing

The dataset is automatically loaded and processed by `datasetLoader.ts`:
- **Consistency Checker**: Calculates consistency scores based on symptom patterns
- **Disease Prediction**: Maps labels to disease classes and creates one-hot encoded vectors
- **Risk Assessment**: Calculates risk scores based on symptoms and metadata

### Usage

The training scripts (`trainDisease.ts`, `trainConsistency.ts`, `trainRisk.ts`) automatically load this dataset when you run:

```bash
npm run train
```

All three models will be trained using the real dataset instead of synthetic data.

