import * as tf from '@tensorflow/tfjs';
import * as path from 'path';
import * as fs from 'fs';
import { ConsistencyCheckerModel } from '../models/consistencyChecker';
import { loadDataset, prepareConsistencyData } from './datasetLoader';
import { trainTestSplit } from '../preprocess';

/**
 * Retrain Consistency Checker Model with improved manipulation detection
 */
export async function retrainConsistencyModel(): Promise<void> {
  console.log('========================================');
  console.log('Retraining Consistency Checker Model');
  console.log('Improved Manipulation Detection');
  console.log('========================================\n');

  // Regenerate dataset first to include manipulation examples
  console.log('Step 1: Regenerating dataset with manipulation examples...');
  const { generateAndSaveDataset } = require('../../dataset/generateMedicalDataset');
  generateAndSaveDataset();
  console.log('Dataset regenerated!\n');

  // Load dataset
  let datasetPath = path.join(__dirname, 'datasets', 'medical_dataset_3000.csv');
  if (!fs.existsSync(datasetPath)) {
    datasetPath = path.join(__dirname, 'datasets', 'baymax_dataset.csv');
  }
  if (!fs.existsSync(datasetPath)) {
    console.error(`Dataset not found. Please run: npm run generate-dataset`);
    process.exit(1);
  }

  console.log(`Step 2: Loading dataset from: ${datasetPath}`);
  const dataset = loadDataset(datasetPath);
  console.log(`Loaded ${dataset.length} samples\n`);

  // Prepare training data
  console.log('Step 3: Preprocessing data with improved manipulation detection...');
  const { xs, ys } = prepareConsistencyData(dataset);
  console.log(`Prepared ${xs.length} training samples\n`);

  // Train-test split
  const combined = xs.map((x, i) => ({ features: x, label: ys[i] }));
  const { train, test } = trainTestSplit(combined, 0.2);
  
  const trainXs = train.map(item => item.features);
  const trainYs = train.map(item => item.label);
  const testXs = test.map(item => item.features);
  const testYs = test.map(item => item.label);

  console.log(`Training set: ${trainXs.length} samples`);
  console.log(`Test set: ${testXs.length} samples\n`);

  // Convert to tensors
  const trainXTensor = tf.tensor2d(trainXs);
  const trainYTensor = tf.tensor2d(trainYs);
  const testXTensor = tf.tensor2d(testXs);
  const testYTensor = tf.tensor2d(testYs);

  // Create and initialize model
  const model = new ConsistencyCheckerModel(trainXs[0].length);
  await model.initialize();
  
  const modelInstance = model.getModel();
  if (!modelInstance) {
    throw new Error('Model not initialized');
  }

  console.log('Step 4: Starting training with improved architecture...\n');

  // Train the model with more epochs for better learning
  const history = await modelInstance.fit(trainXTensor, trainYTensor, {
    epochs: 100, // Increased from 50
    batchSize: 32,
    validationSplit: 0.2,
    callbacks: {
      onEpochEnd: (epoch, logs) => {
        if ((epoch + 1) % 10 === 0 || epoch === 0) {
          console.log(
            `Epoch ${epoch + 1}/100 - ` +
            `loss: ${logs?.loss?.toFixed(4)} - ` +
            `acc: ${logs?.acc?.toFixed(4)} - ` +
            `val_loss: ${logs?.val_loss?.toFixed(4)} - ` +
            `val_acc: ${logs?.val_acc?.toFixed(4)}`
          );
        }
      }
    }
  });

  console.log('\nTraining complete!\n');

  // Evaluate on test set
  console.log('Step 5: Evaluating on test set...');
  const predictions = modelInstance.predict(testXTensor) as tf.Tensor;
  const testLoss = await modelInstance.evaluate(testXTensor, testYTensor);
  
  if (Array.isArray(testLoss)) {
    console.log(`Test Loss: ${testLoss[0].arraySync()}`);
  }

  // Test with manipulation examples
  console.log('\nStep 6: Testing manipulation detection...');
  const manipulationTest = new Array(52).fill(0.8); // Simulate many symptoms
  const manipulationTensor = tf.tensor2d([manipulationTest]);
  const manipulationPred = modelInstance.predict(manipulationTensor) as tf.Tensor;
  const manipulationValues = await manipulationPred.data();
  console.log(`Manipulation test (many symptoms):`);
  console.log(`  Consistency: ${(manipulationValues[0] * 100).toFixed(1)}%`);
  console.log(`  Manipulation: ${(manipulationValues[1] * 100).toFixed(1)}%`);
  console.log(`  Warning: ${(manipulationValues[2] * 100).toFixed(1)}%`);
  manipulationTensor.dispose();
  manipulationPred.dispose();

  // Save model
  const modelsDir = path.join(__dirname, '..', '..', 'models', 'consistency');
  if (!fs.existsSync(modelsDir)) {
    fs.mkdirSync(modelsDir, { recursive: true });
  }
  
  await model.saveModel(modelsDir);
  console.log(`\nModel saved to: ${modelsDir}`);

  // Clean up tensors
  trainXTensor.dispose();
  trainYTensor.dispose();
  testXTensor.dispose();
  testYTensor.dispose();
  predictions.dispose();

  console.log('\n✅ Consistency model retrained with improved manipulation detection!');
  console.log('The model now better detects:');
  console.log('  - Too many symptoms (>20)');
  console.log('  - Multiple body systems affected');
  console.log('  - Contradictory symptoms');
  console.log('  - Unrealistic severity patterns');
}

if (require.main === module) {
  retrainConsistencyModel().catch(console.error);
}

