import { trainConsistencyModel } from './trainConsistencyModel';
import { trainDiseaseModel } from './trainDiseaseModel';
import { trainRiskModel } from './trainRiskModel';

/**
 * Train all models
 */
async function trainAll(): Promise<void> {
  console.log('🚀 Starting training for all models...\n');

  try {
    await trainConsistencyModel();
    console.log('\n');
    
    await trainDiseaseModel();
    console.log('\n');
    
    await trainRiskModel();
    console.log('\n');
    
    console.log('✅ All models trained successfully!');
    console.log('Models saved to: models/ directory');
  } catch (error) {
    console.error('❌ Training failed:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  trainAll();
}

