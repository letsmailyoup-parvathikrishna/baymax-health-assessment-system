import * as tf from '@tensorflow/tfjs';
import * as path from 'path';
import { ConsistencyCheckerModel } from '../consistencyModel';
import { loadDataset, prepareConsistencyData } from './datasetLoader';

/**
 * Training script for consistency checker model using real dataset
 */
export async function trainConsistencyModel(): Promise<void> {
  console.log('Training Consistency Checker Model...');

  // Load dataset
  const datasetPath = path.join(__dirname, 'datasets', 'baymax_dataset.csv');
  console.log(`Loading dataset from: ${datasetPath}`);
  
  const dataset = loadDataset(datasetPath);
  console.log(`Loaded ${dataset.length} samples`);

  // Prepare training data
  const { xs, ys } = prepareConsistencyData(dataset);
  console.log(`Prepared ${xs.length} training samples`);

  // Convert to tensors
  const xsTensor = tf.tensor2d(xs);
  const ysTensor = tf.tensor2d(ys);

  const model = new ConsistencyCheckerModel();
  await model.initialize();

  const modelInstance = model.getModel();
  if (!modelInstance) {
    throw new Error('Model not initialized');
  }

  // Train the model
  await modelInstance.fit(xsTensor, ysTensor, {
    epochs: 50,
    batchSize: 32,
    validationSplit: 0.2,
    callbacks: {
      onEpochEnd: (epoch, logs) => {
        console.log(`Epoch ${epoch + 1}: loss = ${logs?.loss?.toFixed(4)}`);
      }
    }
  });

  // Clean up tensors
  xsTensor.dispose();
  ysTensor.dispose();

  console.log('Consistency model training complete!');
  // Save the model:
  // await modelInstance.save('file://./models/consistency');
}

if (require.main === module) {
  trainConsistencyModel().catch(console.error);
}

