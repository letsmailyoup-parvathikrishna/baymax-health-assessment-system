import * as tf from '@tensorflow/tfjs';
import * as path from 'path';
import * as fs from 'fs';
import { ConsistencyCheckerModel } from '../models/consistencyChecker';
import { loadDataset, prepareConsistencyData } from './datasetLoader';
import { trainTestSplit } from '../preprocess';

/**
 * Train Consistency Checker Model with evaluation and model saving
 */
export async function trainConsistencyModel(): Promise<void> {
  console.log('========================================');
  console.log('Training Consistency Checker Model');
  console.log('========================================\n');

  // Load dataset (prioritize larger datasets for better accuracy)
  let datasetPath = path.join(__dirname, 'datasets', 'baymax_medical_dataset_v2_5000.csv');
  if (!fs.existsSync(datasetPath)) {
    datasetPath = path.join(__dirname, 'datasets', 'medical_dataset_3000.csv');
  }
  if (!fs.existsSync(datasetPath)) {
    datasetPath = path.join(__dirname, 'datasets', 'baymax_dataset.csv');
  }
  if (!fs.existsSync(datasetPath)) {
    console.error(`Dataset not found. Please run: npm run generate-dataset`);
    process.exit(1);
  }

  console.log(`Loading dataset from: ${datasetPath}`);
  const dataset = loadDataset(datasetPath);
  console.log(`Loaded ${dataset.length} samples\n`);

  // Prepare training data
  console.log('Preprocessing data...');
  const { xs, ys } = prepareConsistencyData(dataset);
  console.log(`Prepared ${xs.length} training samples\n`);

  // Train-test split
  const combined = xs.map((x, i) => ({ features: x, label: ys[i] }));
  const { train, test } = trainTestSplit(combined, 0.2);
  
  const trainXs = train.map(item => item.features);
  const trainYs = train.map(item => item.label);
  const testXs = test.map(item => item.features);
  const testYs = test.map(item => item.label);

  console.log(`Training set: ${trainXs.length} samples`);
  console.log(`Test set: ${testXs.length} samples\n`);

  // Convert to tensors
  const trainXTensor = tf.tensor2d(trainXs);
  const trainYTensor = tf.tensor2d(trainYs);
  const testXTensor = tf.tensor2d(testXs);
  const testYTensor = tf.tensor2d(testYs);

  // Create and initialize model
  const model = new ConsistencyCheckerModel(trainXs[0].length);
  await model.initialize();
  
  const modelInstance = model.getModel();
  if (!modelInstance) {
    throw new Error('Model not initialized');
  }

  console.log('Starting training...\n');

  // Train the model
  const history = await modelInstance.fit(trainXTensor, trainYTensor, {
    epochs: 50,
    batchSize: 32,
    validationSplit: 0.2,
    callbacks: {
      onEpochEnd: (epoch, logs) => {
        if ((epoch + 1) % 10 === 0 || epoch === 0) {
          console.log(
            `Epoch ${epoch + 1}/50 - ` +
            `loss: ${logs?.loss?.toFixed(4)} - ` +
            `val_loss: ${logs?.val_loss?.toFixed(4)}`
          );
        }
      }
    }
  });

  console.log('\nTraining complete!\n');

  // Evaluate on test set
  console.log('Evaluating on test set...');
  const predictions = modelInstance.predict(testXTensor) as tf.Tensor;
  const testLoss = await modelInstance.evaluate(testXTensor, testYTensor);
  
  if (Array.isArray(testLoss)) {
    console.log(`Test Loss: ${testLoss[0].arraySync()}`);
  }

  // Save model (will skip if not supported)
  const modelsDir = path.join(__dirname, '..', '..', 'models', 'consistency');
  if (!fs.existsSync(modelsDir)) {
    fs.mkdirSync(modelsDir, { recursive: true });
  }
  
  try {
    await model.saveModel(modelsDir);
  } catch (error) {
    console.log('\nNote: Model could not be saved (file:// not supported with @tensorflow/tfjs)');
    console.log('Model is trained and ready to use in memory.');
  }

  // Clean up tensors
  trainXTensor.dispose();
  trainYTensor.dispose();
  testXTensor.dispose();
  testYTensor.dispose();
  predictions.dispose();

  console.log('\nConsistency model training complete!');
}

if (require.main === module) {
  trainConsistencyModel().catch(console.error);
}

