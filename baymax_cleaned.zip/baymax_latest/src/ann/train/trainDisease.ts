import * as tf from '@tensorflow/tfjs';
import * as path from 'path';
import { DiseasePredictionModel } from '../diseaseModel';
import { loadDataset, prepareTrainingData } from './datasetLoader';

/**
 * Training script for disease prediction model using real dataset
 */
export async function trainDiseaseModel(): Promise<void> {
  console.log('Training Disease Prediction Model...');

  // Load dataset
  const datasetPath = path.join(__dirname, 'datasets', 'baymax_dataset.csv');
  console.log(`Loading dataset from: ${datasetPath}`);
  
  const dataset = loadDataset(datasetPath);
  console.log(`Loaded ${dataset.length} samples`);

  // Prepare training data
  const { xs, ys } = prepareTrainingData(dataset);
  console.log(`Prepared ${xs.length} training samples`);

  // Convert to tensors
  const xsTensor = tf.tensor2d(xs);
  const ysTensor = tf.tensor2d(ys);

  const model = new DiseasePredictionModel();
  await model.initialize();

  const modelInstance = model.getModel();
  if (!modelInstance) {
    throw new Error('Model not initialized');
  }

  // Train the model
  await modelInstance.fit(xsTensor, ysTensor, {
    epochs: 100,
    batchSize: 32,
    validationSplit: 0.2,
    callbacks: {
      onEpochEnd: (epoch, logs) => {
        console.log(`Epoch ${epoch + 1}: loss = ${logs?.loss?.toFixed(4)}, acc = ${logs?.acc?.toFixed(4)}`);
      }
    }
  });

  // Clean up tensors
  xsTensor.dispose();
  ysTensor.dispose();

  console.log('Disease model training complete!');
  // Save the model:
  // await modelInstance.save('file://./models/disease');
}

if (require.main === module) {
  trainDiseaseModel().catch(console.error);
}

