import * as tf from '@tensorflow/tfjs';
import * as path from 'path';
import * as fs from 'fs';
import { DiseaseClassifierModel } from '../models/diseaseClassifier';
import { loadDataset, prepareTrainingData, mapLabelToDiseaseClass } from './datasetLoader';
import { trainTestSplit, oneHotEncode, DISEASE_CLASSES } from '../preprocess';
import { calculateAllMetrics, printMetrics } from '../metrics';

/**
 * Train Disease Classifier Model with evaluation and model saving
 */
export async function trainDiseaseModel(): Promise<void> {
  console.log('========================================');
  console.log('Training Disease Classifier Model');
  console.log('========================================\n');

  // Load dataset (prioritize larger datasets for better accuracy)
  const datasetsDir = path.join(__dirname, 'datasets');
  console.log(`Checking datasets in: ${datasetsDir}`);
  
  let datasetPath = path.join(datasetsDir, 'baymax_medical_dataset_v2_5000.csv');
  console.log(`Checking for 5000-sample dataset: ${datasetPath}`);
  if (!fs.existsSync(datasetPath)) {
    console.log('  5000-sample dataset not found, trying 3000-sample...');
    datasetPath = path.join(datasetsDir, 'medical_dataset_3000.csv');
    if (!fs.existsSync(datasetPath)) {
      console.log('  3000-sample dataset not found, using 1000-sample...');
      datasetPath = path.join(datasetsDir, 'baymax_dataset.csv');
    }
  } else {
    console.log('  ✓ Found 5000-sample dataset!');
  }
  
  if (!fs.existsSync(datasetPath)) {
    console.error(`\n❌ Dataset not found in ${datasetsDir}`);
    console.error(`Please copy baymax_medical_dataset_v2_5000.csv to: ${datasetsDir}`);
    console.error(`Or run: npm run generate-dataset`);
    process.exit(1);
  }

  console.log(`\nLoading dataset from: ${datasetPath}`);
  const dataset = loadDataset(datasetPath);
  console.log(`Loaded ${dataset.length} samples\n`);

  // Prepare training data
  console.log('Preprocessing data...');
  const { xs, ys } = prepareTrainingData(dataset);
  console.log(`Prepared ${xs.length} training samples\n`);

  // Train-test split
  const combined = xs.map((x, i) => ({ features: x, label: ys[i] }));
  const { train, test } = trainTestSplit(combined, 0.2);
  
  const trainXs = train.map(item => item.features);
  const trainYs = train.map(item => item.label);
  const testXs = test.map(item => item.features);
  const testYs = test.map(item => item.label);

  console.log(`Training set: ${trainXs.length} samples`);
  console.log(`Test set: ${testXs.length} samples\n`);

  // Convert to tensors
  const trainXTensor = tf.tensor2d(trainXs);
  const trainYTensor = tf.tensor2d(trainYs);
  const testXTensor = tf.tensor2d(testXs);
  const testYTensor = tf.tensor2d(testYs);

  // Create and initialize model
  const model = new DiseaseClassifierModel(trainXs[0].length);
  await model.initialize();
  
  const modelInstance = model.getModel();
  if (!modelInstance) {
    throw new Error('Model not initialized');
  }

  console.log('Model Architecture:');
  model.getSummary();
  console.log('\n');

  // Train the model with early stopping to prevent overfitting
  console.log('Starting training...\n');
  let bestValLoss = Infinity;
  let patience = 0;
  const maxPatience = 10; // Stop if no improvement for 10 epochs
  let bestEpoch = 0;
  let shouldStop = false;
  
  const history = await modelInstance.fit(trainXTensor, trainYTensor, {
    epochs: 50, // Reduced from 100 to prevent overfitting
    batchSize: 32,
    validationSplit: 0.2,
    callbacks: {
      onEpochEnd: async (epoch, logs) => {
        const valLoss = logs?.val_loss as number;
        const valAcc = logs?.val_acc as number;
        
        // Early stopping logic
        if (valLoss < bestValLoss) {
          bestValLoss = valLoss;
          patience = 0;
          bestEpoch = epoch;
        } else {
          patience++;
        }
        
        if ((epoch + 1) % 5 === 0 || epoch === 0) {
          console.log(
            `Epoch ${epoch + 1}/50 - ` +
            `loss: ${logs?.loss?.toFixed(4)} - ` +
            `acc: ${logs?.acc?.toFixed(4)} - ` +
            `val_loss: ${valLoss?.toFixed(4)} - ` +
            `val_acc: ${valAcc?.toFixed(4)}` +
            (epoch === bestEpoch ? ' ⭐ BEST' : '')
          );
        }
        
        // Early stopping warning
        if (patience >= maxPatience && !shouldStop) {
          console.log(`\n⚠️  No improvement for ${maxPatience} epochs. Consider stopping training.`);
          console.log(`Best validation loss: ${bestValLoss.toFixed(4)} at epoch ${bestEpoch + 1}`);
          shouldStop = true;
        }
      }
    }
  });
  
  if (shouldStop) {
    console.log(`\n✅ Training completed. Best model was at epoch ${bestEpoch + 1}`);
  }

  console.log('\nTraining complete!\n');

  // Evaluate on test set
  console.log('Evaluating on test set...');
  const predictions = modelInstance.predict(testXTensor) as tf.Tensor;
  
  // Calculate metrics
  const { metrics, confusionMatrix, rocAuc } = calculateAllMetrics(
    testYTensor,
    predictions,
    DISEASE_CLASSES
  );

  // Print metrics
  printMetrics(metrics, confusionMatrix, rocAuc, DISEASE_CLASSES);

  // Save model (will skip if not supported)
  const modelsDir = path.join(__dirname, '..', '..', 'models', 'disease');
  if (!fs.existsSync(modelsDir)) {
    fs.mkdirSync(modelsDir, { recursive: true });
  }
  
  try {
    await model.saveModel(modelsDir);
  } catch (error) {
    console.log('\nNote: Model could not be saved (file:// not supported with @tensorflow/tfjs)');
    console.log('Model is trained and ready to use in memory.');
  }

  // Clean up tensors
  trainXTensor.dispose();
  trainYTensor.dispose();
  testXTensor.dispose();
  testYTensor.dispose();
  predictions.dispose();

  console.log('\nDisease model training complete!');
}

if (require.main === module) {
  trainDiseaseModel().catch(console.error);
}

