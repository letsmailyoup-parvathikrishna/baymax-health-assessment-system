import * as fs from 'fs';
import * as path from 'path';

interface MedicalSample {
  symptoms: number[];
  age: number;
  gender: number;
  stressLevel: number;
  sleepHours: number;
  waterIntake: number;
  label: string;
  severity: number;
}

// Symptom indices matching dataset structure
const SYMPTOM_INDICES = {
  fever: 0,
  cough: 1,
  runny_nose: 2,
  sore_throat: 3,
  headache: 4,
  body_ache: 5,
  fatigue: 6,
  loss_of_smell: 7,
  loss_of_taste: 8,
  nausea: 9,
  vomiting: 10,
  diarrhea: 11,
  stomach_cramps: 12,
  chest_pain: 13,
  difficulty_breathing: 14,
  dizziness: 15,
  rapid_heartbeat: 16,
  chills: 17,
  rash: 18,
  itchy_skin: 19,
  joint_pain: 20,
  burning_urination: 21,
  frequent_urination: 22,
  lower_abdominal_pain: 23,
  bloating: 24,
  gas: 25,
  dehydration_signs: 26,
  dry_mouth: 27,
  sensitivity_to_light: 28,
  anxiety: 29,
  restlessness: 30,
  trembling: 31,
  sweating: 32,
  irritability: 33,
  trouble_sleeping: 34,
  appetite_loss: 35,
  weight_loss: 36,
  weight_gain: 37,
  throat_itchiness: 38,
  congestion: 2, // Use runny_nose index
  sneezing: 2, // Use runny_nose index  
  itchy_eyes: 19, // Use itchy_skin index
  stomach_pain: 12, // Use stomach_cramps index
  back_pain: 20, // Use joint_pain index
  thirst: 27 // Use dry_mouth index
};

/**
 * Generate medically accurate dataset samples
 */
function generateMedicalDataset(): MedicalSample[] {
  const samples: MedicalSample[] = [];
  const numSamples = 3000;

  // ========== FLU SAMPLES ==========
  for (let i = 0; i < 400; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 70) + 10;
    const severity = Math.random() * 0.4 + 0.5; // 0.5-0.9
    
    // Core flu symptoms
    symptoms[SYMPTOM_INDICES.fever] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.cough] = Math.random() > 0.15 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.body_ache] = Math.random() > 0.25 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.chills] = Math.random() > 0.3 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.fatigue] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.headache] = Math.random() > 0.4 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.sore_throat] = Math.random() > 0.5 ? 1 : 0;
    
    // Sometimes runny nose, but less common than cold
    symptoms[SYMPTOM_INDICES.runny_nose] = Math.random() > 0.6 ? 1 : 0;
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.5,
      sleepHours: 4 + Math.random() * 4,
      waterIntake: 1 + Math.random() * 3,
      label: 'flu',
      severity
    });
  }

  // ========== COMMON COLD SAMPLES ==========
  for (let i = 0; i < 400; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 80) + 5;
    const severity = Math.random() * 0.3 + 0.3; // 0.3-0.6
    
    // Core cold symptoms (no fever usually)
    symptoms[SYMPTOM_INDICES.runny_nose] = Math.random() > 0.1 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.runny_nose] = Math.random() > 0.15 ? Math.max(symptoms[SYMPTOM_INDICES.runny_nose], 1) : symptoms[SYMPTOM_INDICES.runny_nose]; // congestion
    symptoms[SYMPTOM_INDICES.sore_throat] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.runny_nose] = Math.random() > 0.25 ? Math.max(symptoms[SYMPTOM_INDICES.runny_nose], 1) : symptoms[SYMPTOM_INDICES.runny_nose]; // sneezing
    symptoms[SYMPTOM_INDICES.cough] = Math.random() > 0.3 ? 1 : 0;
    
    // Less common in cold
    symptoms[SYMPTOM_INDICES.fever] = Math.random() > 0.85 ? 1 : 0; // Rare
    symptoms[SYMPTOM_INDICES.body_ache] = Math.random() > 0.8 ? 1 : 0; // Rare
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.4,
      sleepHours: 6 + Math.random() * 3,
      waterIntake: 2 + Math.random() * 2,
      label: 'common_cold',
      severity
    });
  }

  // ========== COVID SAMPLES ==========
  for (let i = 0; i < 350; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 80) + 10;
    const severity = Math.random() * 0.5 + 0.4; // 0.4-0.9
    
    // Strong COVID indicators
    symptoms[SYMPTOM_INDICES.loss_of_smell] = Math.random() > 0.3 ? 1 : 0; // Strong indicator
    symptoms[SYMPTOM_INDICES.loss_of_taste] = Math.random() > 0.35 ? 1 : 0; // Strong indicator
    symptoms[SYMPTOM_INDICES.fever] = Math.random() > 0.25 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.cough] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.difficulty_breathing] = Math.random() > 0.4 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.fatigue] = Math.random() > 0.3 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.body_ache] = Math.random() > 0.4 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.headache] = Math.random() > 0.5 ? 1 : 0;
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.6 + 0.2,
      sleepHours: 5 + Math.random() * 4,
      waterIntake: 1.5 + Math.random() * 2.5,
      label: 'covid',
      severity
    });
  }

  // ========== ALLERGY SAMPLES ==========
  for (let i = 0; i < 300; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 70) + 5;
    const severity = Math.random() * 0.3 + 0.2; // 0.2-0.5
    
    // Allergy symptoms (NO fever)
    symptoms[SYMPTOM_INDICES.runny_nose] = Math.random() > 0.1 ? 1 : 0; // sneezing
    symptoms[SYMPTOM_INDICES.itchy_skin] = Math.random() > 0.15 ? 1 : 0; // itchy_eyes
    symptoms[SYMPTOM_INDICES.runny_nose] = Math.random() > 0.2 ? Math.max(symptoms[SYMPTOM_INDICES.runny_nose], 1) : symptoms[SYMPTOM_INDICES.runny_nose];
    symptoms[SYMPTOM_INDICES.itchy_skin] = Math.random() > 0.3 ? Math.max(symptoms[SYMPTOM_INDICES.itchy_skin], 1) : symptoms[SYMPTOM_INDICES.itchy_skin];
    symptoms[SYMPTOM_INDICES.rash] = Math.random() > 0.4 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.throat_itchiness] = Math.random() > 0.5 ? 1 : 0;
    
    // NO fever, body ache, or chills
    symptoms[SYMPTOM_INDICES.fever] = 0;
    symptoms[SYMPTOM_INDICES.body_ache] = 0;
    symptoms[SYMPTOM_INDICES.chills] = 0;
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.3,
      sleepHours: 6 + Math.random() * 3,
      waterIntake: 2 + Math.random() * 2,
      label: 'allergy',
      severity
    });
  }

  // ========== MIGRAINE SAMPLES ==========
  for (let i = 0; i < 250; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 60) + 15;
    const severity = Math.random() * 0.4 + 0.5; // 0.5-0.9
    
    // Migraine symptoms (NO fever, NO respiratory)
    symptoms[SYMPTOM_INDICES.headache] = 1; // Always present
    symptoms[SYMPTOM_INDICES.sensitivity_to_light] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.nausea] = Math.random() > 0.3 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.dizziness] = Math.random() > 0.4 ? 1 : 0;
    
    // NO fever, cough, runny nose
    symptoms[SYMPTOM_INDICES.fever] = 0;
    symptoms[SYMPTOM_INDICES.cough] = 0;
    symptoms[SYMPTOM_INDICES.runny_nose] = 0;
    symptoms[SYMPTOM_INDICES.body_ache] = 0;
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.4 ? 1 : 0, // Slightly more common in women
      stressLevel: Math.random() * 0.7 + 0.3,
      sleepHours: 4 + Math.random() * 4,
      waterIntake: 1.5 + Math.random() * 2,
      label: 'migraine',
      severity
    });
  }

  // ========== STOMACH INFECTION SAMPLES ==========
  for (let i = 0; i < 300; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 70) + 5;
    const severity = Math.random() * 0.4 + 0.4; // 0.4-0.8
    
    // GI symptoms
    symptoms[SYMPTOM_INDICES.stomach_cramps] = Math.random() > 0.15 ? 1 : 0; // stomach_pain
    symptoms[SYMPTOM_INDICES.stomach_cramps] = Math.random() > 0.2 ? Math.max(symptoms[SYMPTOM_INDICES.stomach_cramps], 1) : symptoms[SYMPTOM_INDICES.stomach_cramps];
    symptoms[SYMPTOM_INDICES.nausea] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.vomiting] = Math.random() > 0.3 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.diarrhea] = Math.random() > 0.25 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.bloating] = Math.random() > 0.4 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.gas] = Math.random() > 0.5 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.lower_abdominal_pain] = Math.random() > 0.35 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.appetite_loss] = Math.random() > 0.3 ? 1 : 0;
    
    // Sometimes fever
    symptoms[SYMPTOM_INDICES.fever] = Math.random() > 0.6 ? 1 : 0;
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.4,
      sleepHours: 5 + Math.random() * 3,
      waterIntake: 1 + Math.random() * 2,
      label: 'stomach_infection',
      severity
    });
  }

  // ========== UTI SAMPLES ==========
  for (let i = 0; i < 250; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 70) + 15;
    const severity = Math.random() * 0.5 + 0.4; // 0.4-0.9
    
    // UTI symptoms
    symptoms[SYMPTOM_INDICES.burning_urination] = Math.random() > 0.1 ? 1 : 0; // Strong indicator
    symptoms[SYMPTOM_INDICES.frequent_urination] = Math.random() > 0.15 ? 1 : 0; // Strong indicator
    symptoms[SYMPTOM_INDICES.lower_abdominal_pain] = Math.random() > 0.3 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.joint_pain] = Math.random() > 0.5 ? 1 : 0; // back_pain
    
    // NO respiratory or GI symptoms
    symptoms[SYMPTOM_INDICES.cough] = 0;
    symptoms[SYMPTOM_INDICES.runny_nose] = 0;
    symptoms[SYMPTOM_INDICES.nausea] = Math.random() > 0.7 ? 1 : 0; // Rare
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.3 ? 1 : 0, // More common in women
      stressLevel: Math.random() * 0.5,
      sleepHours: 5 + Math.random() * 3,
      waterIntake: 1.5 + Math.random() * 2.5,
      label: 'urinary_infection',
      severity
    });
  }

  // ========== DEHYDRATION SAMPLES ==========
  for (let i = 0; i < 200; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 80) + 5;
    const severity = Math.random() * 0.4 + 0.3; // 0.3-0.7
    
    // Dehydration symptoms
    symptoms[SYMPTOM_INDICES.dry_mouth] = Math.random() > 0.1 ? 1 : 0; // thirst
    symptoms[SYMPTOM_INDICES.dry_mouth] = Math.random() > 0.15 ? Math.max(symptoms[SYMPTOM_INDICES.dry_mouth], 1) : symptoms[SYMPTOM_INDICES.dry_mouth];
    symptoms[SYMPTOM_INDICES.dehydration_signs] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.fatigue] = Math.random() > 0.25 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.dizziness] = Math.random() > 0.3 ? 1 : 0;
    
    // Often with vomiting/diarrhea
    symptoms[SYMPTOM_INDICES.vomiting] = Math.random() > 0.5 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.diarrhea] = Math.random() > 0.5 ? 1 : 0;
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.3,
      sleepHours: 4 + Math.random() * 4,
      waterIntake: 0.5 + Math.random() * 1.5, // Low water intake
      label: 'dehydration',
      severity
    });
  }

  // ========== ANXIETY SAMPLES ==========
  for (let i = 0; i < 250; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 60) + 15;
    const severity = Math.random() * 0.5 + 0.3; // 0.3-0.8
    
    // Anxiety symptoms
    symptoms[SYMPTOM_INDICES.anxiety] = Math.random() > 0.1 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.rapid_heartbeat] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.restlessness] = Math.random() > 0.3 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.trembling] = Math.random() > 0.4 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.irritability] = Math.random() > 0.4 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.trouble_sleeping] = Math.random() > 0.5 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.sweating] = Math.random() > 0.5 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.dizziness] = Math.random() > 0.6 ? 1 : 0;
    
    // NO fever, cough, body ache
    symptoms[SYMPTOM_INDICES.fever] = 0;
    symptoms[SYMPTOM_INDICES.cough] = 0;
    symptoms[SYMPTOM_INDICES.body_ache] = 0;
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.45 ? 1 : 0,
      stressLevel: Math.random() * 0.5 + 0.5, // High stress
      sleepHours: 3 + Math.random() * 4,
      waterIntake: 1.5 + Math.random() * 2,
      label: 'anxiety_attack',
      severity
    });
  }

  // ========== FOOD POISONING SAMPLES ==========
  for (let i = 0; i < 300; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 70) + 5;
    const severity = Math.random() * 0.5 + 0.4; // 0.4-0.9
    
    // Food poisoning symptoms (acute GI)
    symptoms[SYMPTOM_INDICES.nausea] = Math.random() > 0.1 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.vomiting] = Math.random() > 0.15 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.diarrhea] = Math.random() > 0.2 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.stomach_cramps] = Math.random() > 0.25 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.stomach_cramps] = Math.random() > 0.3 ? Math.max(symptoms[SYMPTOM_INDICES.stomach_cramps], 1) : symptoms[SYMPTOM_INDICES.stomach_cramps]; // stomach_pain
    symptoms[SYMPTOM_INDICES.bloating] = Math.random() > 0.4 ? 1 : 0;
    symptoms[SYMPTOM_INDICES.fatigue] = Math.random() > 0.5 ? 1 : 0;
    
    // Sometimes fever
    symptoms[SYMPTOM_INDICES.fever] = Math.random() > 0.6 ? 1 : 0;
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.3,
      sleepHours: 4 + Math.random() * 3,
      waterIntake: 1 + Math.random() * 2,
      label: 'food_poisoning',
      severity
    });
  }

  // ========== ADD MANIPULATION EXAMPLES ==========
  // Generate examples of manipulated/inconsistent inputs
  for (let i = 0; i < 200; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 70) + 10;
    
    // Manipulation pattern: Too many symptoms (25-39)
    const numSymptoms = Math.floor(Math.random() * 15) + 25; // 25-39 symptoms
    
    // Randomly select symptoms
    const selectedIndices = new Set<number>();
    while (selectedIndices.size < numSymptoms) {
      selectedIndices.add(Math.floor(Math.random() * 39));
    }
    
    selectedIndices.forEach(idx => {
      symptoms[idx] = 1;
    });
    
    // Add contradictions
    if (Math.random() > 0.5) {
      symptoms[SYMPTOM_INDICES.diarrhea] = 1;
      // Note: constipation not in dataset, but we can add other contradictions
    }
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.5,
      sleepHours: 4 + Math.random() * 4,
      waterIntake: 1 + Math.random() * 3,
      label: 'manipulated', // Special label for training
      severity: Math.random() * 0.3 + 0.1 // Low severity (manipulated)
    });
  }

  // ========== ADD INCONSISTENT EXAMPLES ==========
  // Examples with too many different body systems
  for (let i = 0; i < 150; i++) {
    const symptoms = new Array(39).fill(0);
    const age = Math.floor(Math.random() * 70) + 10;
    
    // Select symptoms from 4+ different systems
    // Respiratory
    symptoms[SYMPTOM_INDICES.cough] = 1;
    symptoms[SYMPTOM_INDICES.runny_nose] = 1;
    // GI
    symptoms[SYMPTOM_INDICES.nausea] = 1;
    symptoms[SYMPTOM_INDICES.vomiting] = 1;
    // Urinary
    symptoms[SYMPTOM_INDICES.burning_urination] = 1;
    // Neurological
    symptoms[SYMPTOM_INDICES.headache] = 1;
    symptoms[SYMPTOM_INDICES.dizziness] = 1;
    // Psychological
    symptoms[SYMPTOM_INDICES.anxiety] = 1;
    // Cardiac
    symptoms[SYMPTOM_INDICES.chest_pain] = 1;
    // Add more random symptoms
    const additionalSymptoms = Math.floor(Math.random() * 10) + 5;
    for (let j = 0; j < additionalSymptoms; j++) {
      const idx = Math.floor(Math.random() * 39);
      symptoms[idx] = 1;
    }
    
    samples.push({
      symptoms,
      age,
      gender: Math.random() > 0.5 ? 1 : 0,
      stressLevel: Math.random() * 0.5,
      sleepHours: 4 + Math.random() * 4,
      waterIntake: 1 + Math.random() * 3,
      label: 'inconsistent', // Special label
      severity: Math.random() * 0.4 + 0.2
    });
  }

  // Shuffle samples
  for (let i = samples.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [samples[i], samples[j]] = [samples[j], samples[i]];
  }

  return samples;
}

/**
 * Convert samples to CSV format
 */
function samplesToCSV(samples: MedicalSample[]): string {
  const headers = [
    'fever', 'cough', 'runny_nose', 'sore_throat', 'headache', 'body_ache', 'fatigue',
    'loss_of_smell', 'loss_of_taste', 'nausea', 'vomiting', 'diarrhea', 'stomach_cramps',
    'chest_pain', 'difficulty_breathing', 'dizziness', 'rapid_heartbeat', 'chills', 'rash',
    'itchy_skin', 'joint_pain', 'burning_urination', 'frequent_urination', 'lower_abdominal_pain',
    'bloating', 'gas', 'dehydration_signs', 'dry_mouth', 'sensitivity_to_light', 'anxiety',
    'restlessness', 'trembling', 'sweating', 'irritability', 'trouble_sleeping', 'appetite_loss',
    'weight_loss', 'weight_gain', 'throat_itchiness', 'age', 'gender', 'stress_level',
    'sleep_hours', 'water_intake', 'label'
  ];

  const rows = samples.map(sample => {
    const symptomStr = sample.symptoms.join(',');
    return `${symptomStr},${sample.age},${sample.gender},${sample.stressLevel.toFixed(2)},${sample.sleepHours.toFixed(2)},${sample.waterIntake.toFixed(2)},${sample.label}`;
  });

  return [headers.join(','), ...rows].join('\n');
}

/**
 * Convert samples to JSON format
 */
function samplesToJSON(samples: MedicalSample[]): string {
  return JSON.stringify(samples, null, 2);
}

/**
 * Main function to generate and save dataset
 */
export function generateAndSaveDataset(): void {
  console.log('Generating medically accurate dataset...');
  const samples = generateMedicalDataset();
  console.log(`Generated ${samples.length} samples`);

  // Count by label
  const labelCounts: Record<string, number> = {};
  samples.forEach(s => {
    labelCounts[s.label] = (labelCounts[s.label] || 0) + 1;
  });
  console.log('Label distribution:', labelCounts);

  // Create datasets directory
  const datasetsDir = path.join(__dirname, '..', 'ann', 'train', 'datasets');
  if (!fs.existsSync(datasetsDir)) {
    fs.mkdirSync(datasetsDir, { recursive: true });
  }

  // Save CSV
  const csvPath = path.join(datasetsDir, 'medical_dataset_3000.csv');
  const csvContent = samplesToCSV(samples);
  fs.writeFileSync(csvPath, csvContent, 'utf-8');
  console.log(`Saved CSV to: ${csvPath}`);

  // Save JSON
  const jsonPath = path.join(datasetsDir, 'medical_dataset_3000.json');
  const jsonContent = samplesToJSON(samples);
  fs.writeFileSync(jsonPath, jsonContent, 'utf-8');
  console.log(`Saved JSON to: ${jsonPath}`);

  console.log('Dataset generation complete!');
}

if (require.main === module) {
  generateAndSaveDataset();
}

