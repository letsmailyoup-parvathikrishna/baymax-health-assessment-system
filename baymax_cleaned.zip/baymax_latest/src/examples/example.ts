import { runHealthAnalysis } from '../pipeline/runAnalysis';
import { UserSymptomInput } from '../types';

/**
 * Example usage of the health analysis pipeline
 */
async function example() {
  console.log('🏥 Baymax Health Advisor - Example Analysis\n');

  // Example 1: Flu-like symptoms
  const fluInput: UserSymptomInput = {
    symptoms: ['fever', 'cough', 'body_ache', 'fatigue', 'chills'],
    severity: {
      fever: 7,
      cough: 6,
      body_ache: 7,
      fatigue: 6,
      chills: 5
    },
    duration: 24, // hours
    age: 35,
    gender: 'male'
  };

  console.log('Example 1: Flu-like symptoms');
  console.log('Symptoms:', fluInput.symptoms.join(', '));
  console.log('\nRunning analysis...\n');

  try {
    const report1 = await runHealthAnalysis(fluInput, true); // Use mock LLM
    console.log('Top Disease Probabilities:');
    Object.entries(report1.ann.diseaseProbabilities)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .forEach(([disease, prob]) => {
        console.log(`  ${disease}: ${(prob * 100).toFixed(1)}%`);
      });
    console.log(`\nRisk Level: ${report1.ann.riskEngine.riskLevel}`);
    console.log(`Severity: ${report1.ann.severity}/100`);
    console.log(`\nAdvice:\n${report1.finalAdvice}\n`);
    console.log('='.repeat(80) + '\n');
  } catch (error) {
    console.error('Error:', error);
  }

  // Example 2: Stomach infection
  const stomachInput: UserSymptomInput = {
    symptoms: ['nausea', 'vomiting', 'stomach_pain', 'diarrhea', 'fatigue'],
    severity: {
      nausea: 8,
      vomiting: 7,
      stomach_pain: 6,
      diarrhea: 7,
      fatigue: 5
    },
    duration: 12,
    age: 28,
    gender: 'female'
  };

  console.log('Example 2: Stomach infection symptoms');
  console.log('Symptoms:', stomachInput.symptoms.join(', '));
  console.log('\nRunning analysis...\n');

  try {
    const report2 = await runHealthAnalysis(stomachInput, true);
    console.log('Top Disease Probabilities:');
    Object.entries(report2.ann.diseaseProbabilities)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .forEach(([disease, prob]) => {
        console.log(`  ${disease}: ${(prob * 100).toFixed(1)}%`);
      });
    console.log(`\nRisk Level: ${report2.ann.riskEngine.riskLevel}`);
    console.log(`Emergency Score: ${report2.ann.riskEngine.emergencyScore}/100`);
    console.log(`\nAdvice:\n${report2.finalAdvice}\n`);
  } catch (error) {
    console.error('Error:', error);
  }
}

if (require.main === module) {
  example().catch(console.error);
}

