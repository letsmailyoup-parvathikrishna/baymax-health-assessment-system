import OpenAI from 'openai';
import { BaymaxHealthReport } from '../types';

export class AdviceGenerator {
  private openai: OpenAI | null = null;
  private useMock: boolean;

  constructor(useMock: boolean = false) {
    this.useMock = useMock;
    
    if (!useMock && process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
    } else {
      this.useMock = true;
    }
  }

  /**
   * Generate natural language health advice using GPT-4
   */
  async generateAdvice(report: BaymaxHealthReport): Promise<string> {
    if (this.useMock || !this.openai) {
      console.log('Using mock advice (OpenAI API key not set or useMock=true)');
      return this.mockAdvice(report);
    }

    try {
      const prompt = this.buildAdvicePrompt(report);
      
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: `You are Baymax, a friendly, empathetic healthcare companion from Big Hero 6. Be warm, caring, and supportive. Use simple, clear language. Provide actionable advice. Always encourage professional medical care when needed. You are NOT a replacement for professional medical care.`
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.8,
        max_tokens: 600,
        top_p: 0.9,
        frequency_penalty: 0.3,
        presence_penalty: 0.3
      });

      const advice = response.choices[0]?.message?.content;
      if (!advice) {
        console.warn('Empty response from OpenAI, using mock advice');
        return this.mockAdvice(report);
      }

      return advice.trim();
    } catch (error: any) {
      console.error('LLM advice generation error:', error.message || error);
      console.log('Falling back to mock advice');
      return this.mockAdvice(report);
    }
  }

  /**
   * Build comprehensive advice prompt for GPT-4
   */
  private buildAdvicePrompt(report: BaymaxHealthReport): string {
    const topDiseases = Object.entries(report.ann.diseaseProbabilities)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([disease, prob]) => {
        const diseaseName = disease.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        return `${diseaseName}: ${(prob * 100).toFixed(1)}%`;
      })
      .join('\n');

    const riskLevel = report.ann.riskEngine.riskLevel.toUpperCase();
    const emergencyScore = report.ann.riskEngine.emergencyScore;
    const severity = report.ann.severity;
    const confidence = report.meta.confidence;

    const warnings = report.meta.warnings.length > 0 
      ? report.meta.warnings.join('\n- ')
      : 'None detected';

    return `Generate warm, empathetic health advice as Baymax.

HEALTH ANALYSIS:
Top Disease Probabilities:
${topDiseases}

Risk Level: ${riskLevel}
Emergency Score: ${emergencyScore}/100
Severity Score: ${severity}/100
Confidence: ${confidence}%

Warnings:
${warnings}

Provide:
1. What the symptoms likely indicate
2. Recommended self-care steps
3. When to seek medical attention
4. General wellness tips

Be warm, supportive, and professional.`;
  }

  /**
   * Mock advice generator (fallback)
   */
  private mockAdvice(report: BaymaxHealthReport): string {
    const topDisease = Object.entries(report.ann.diseaseProbabilities)
      .sort((a, b) => b[1] - a[1])[0];

    const diseaseName = topDisease[0].replace(/_/g, ' ');
    const probability = (topDisease[1] * 100).toFixed(1);
    const riskLevel = report.ann.riskEngine.riskLevel;
    const severity = report.ann.severity;

    let advice = `Hello! I'm Baymax, your personal healthcare companion.\n\n`;
    advice += `Based on your symptoms, there's a ${probability}% likelihood of ${diseaseName}.\n\n`;

    if (riskLevel === 'high' || severity > 70) {
      advice += `⚠️ Your symptoms indicate a high risk level. I strongly recommend seeking immediate medical attention, especially if symptoms worsen.\n\n`;
    } else if (riskLevel === 'medium' || severity > 50) {
      advice += `Your symptoms are moderate. Please monitor your condition closely and consider consulting a healthcare provider if symptoms persist or worsen.\n\n`;
    } else {
      advice += `Your symptoms appear to be mild. Try the following self-care measures:\n\n`;
    }

    // Disease-specific advice
    if (diseaseName.includes('flu') || diseaseName.includes('cold')) {
      advice += `• Rest and stay hydrated\n`;
      advice += `• Use over-the-counter medications for fever and pain if needed\n`;
      advice += `• Avoid contact with others to prevent spread\n`;
    } else if (diseaseName.includes('stomach') || diseaseName.includes('food')) {
      advice += `• Stay hydrated with clear fluids\n`;
      advice += `• Avoid solid foods until nausea subsides\n`;
      advice += `• Rest and avoid dairy products\n`;
    } else if (diseaseName.includes('uti')) {
      advice += `• Drink plenty of water\n`;
      advice += `• Avoid caffeine and alcohol\n`;
      advice += `• Consider seeing a doctor for antibiotics\n`;
    } else if (diseaseName.includes('dehydration')) {
      advice += `• Drink water and electrolyte solutions\n`;
      advice += `• Rest in a cool environment\n`;
      advice += `• Monitor urine color (should be light yellow)\n`;
    } else if (diseaseName.includes('migraine')) {
      advice += `• Rest in a dark, quiet room\n`;
      advice += `• Apply cold compress to forehead\n`;
      advice += `• Consider over-the-counter pain relief\n`;
    } else {
      advice += `• Rest and stay hydrated\n`;
      advice += `• Monitor your symptoms\n`;
      advice += `• Seek medical help if symptoms worsen\n`;
    }

    if (report.meta.warnings.length > 0) {
      advice += `\n⚠️ Important: ${report.meta.warnings.join('. ')}\n`;
    }

    advice += `\nRemember, I'm here to help, but I'm not a replacement for professional medical care. If you're concerned about your symptoms, please consult a healthcare provider.\n\n`;
    advice += `Take care! 🏥`;

    return advice;
  }
}

