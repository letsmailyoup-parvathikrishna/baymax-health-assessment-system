import OpenAI from 'openai';
import { UserSymptomInput, LLMValidationResult } from '../types';

export class LLMValidator {
  private openai: OpenAI | null = null;
  private useMock: boolean;

  constructor(useMock: boolean = false) {
    this.useMock = useMock;
    
    if (!useMock && process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
    } else {
      this.useMock = true;
    }
  }

  /**
   * Validate symptoms using LLM
   */
  async validateSymptoms(input: UserSymptomInput): Promise<LLMValidationResult> {
    if (this.useMock || !this.openai) {
      return this.mockValidation(input);
    }

    try {
      const prompt = this.buildValidationPrompt(input);
      
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o', // Use gpt-4o which supports json_object, or remove response_format
        messages: [
          {
            role: 'system',
            content: 'You are a medical consistency-checker. Analyze symptoms for logical compatibility, contradictions, and medical impossibilities. Return only valid JSON in this exact format: {"logical": boolean, "issues": string[], "contradictions": string[], "impossible": string[]}'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.3
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        return this.mockValidation(input);
      }

      // Extract JSON from markdown code blocks if present
      let jsonContent = content.trim();
      if (jsonContent.startsWith('```')) {
        // Remove markdown code block markers
        jsonContent = jsonContent.replace(/^```(?:json)?\n?/i, '').replace(/\n?```$/i, '');
      }

      const result = JSON.parse(jsonContent) as LLMValidationResult;
      return this.normalizeResult(result);
    } catch (error) {
      console.error('LLM validation error:', error);
      return this.mockValidation(input);
    }
  }

  /**
   * Build validation prompt
   */
  private buildValidationPrompt(input: UserSymptomInput): string {
    const symptomsList = input.symptoms.join(', ');
    const severities = Object.entries(input.severity)
      .map(([symptom, severity]) => `${symptom}: ${severity}/10`)
      .join(', ');

    return `You are a medical consistency-checker. 

Given the symptoms, check if they are logical, medically compatible, or contradictory.

Symptoms: ${symptomsList}
Severities: ${severities}
Duration: ${input.duration} hours
Age: ${input.age || 'unknown'}
Gender: ${input.gender || 'unknown'}

Return JSON:
{
  "logical": boolean,
  "issues": string[],
  "contradictions": string[],
  "impossible": string[]
}`;
  }

  /**
   * Mock validation for when OpenAI is not available
   */
  private mockValidation(input: UserSymptomInput): LLMValidationResult {
    const issues: string[] = [];
    const contradictions: string[] = [];
    const impossible: string[] = [];

    const symptomSet = new Set(input.symptoms.map(s => s.toLowerCase()));
    const symptomCount = input.symptoms.length;

    // ========== CRITICAL: Too many symptoms ==========
    if (symptomCount > 25) {
      impossible.push(`Too many symptoms (${symptomCount}) - medically unrealistic`);
    } else if (symptomCount > 20) {
      issues.push(`Very high number of symptoms (${symptomCount}) - may indicate manipulation`);
    } else if (symptomCount > 15) {
      issues.push(`High number of symptoms (${symptomCount}) - please verify accuracy`);
    }

    // ========== Check for contradictions ==========
    if (symptomSet.has('diarrhea') && symptomSet.has('constipation')) {
      contradictions.push('Diarrhea and constipation are contradictory');
    }

    // ========== Check for medically impossible combinations ==========
    // Too many different body systems affected
    const hasRespiratory = symptomSet.has('cough') || symptomSet.has('runny_nose') || symptomSet.has('sneezing') || symptomSet.has('shortness_of_breath');
    const hasGI = symptomSet.has('nausea') || symptomSet.has('vomiting') || symptomSet.has('diarrhea') || symptomSet.has('stomach_pain');
    const hasUrinary = symptomSet.has('burning_urination') || symptomSet.has('frequent_urination');
    const hasNeurological = symptomSet.has('headache') || symptomSet.has('dizziness') || symptomSet.has('confusion');
    const hasPsychological = symptomSet.has('anxiety') || symptomSet.has('irritability') || symptomSet.has('restlessness');
    const hasCardiac = symptomSet.has('chest_pain') || symptomSet.has('rapid_heartbeat');

    const systemCount = [hasRespiratory, hasGI, hasUrinary, hasNeurological, hasPsychological, hasCardiac]
      .filter(Boolean).length;

    if (systemCount >= 5 && symptomCount > 15) {
      impossible.push(`Symptoms affecting ${systemCount} different body systems simultaneously is medically impossible`);
    } else if (systemCount >= 4 && symptomCount > 12) {
      issues.push(`Symptoms affecting ${systemCount} different body systems is highly unusual`);
    }

    // Fever + Allergy (allergies don't cause fever)
    if (symptomSet.has('fever') && symptomSet.has('sneezing') && symptomSet.has('itchy_eyes') && 
        !symptomSet.has('cough') && !symptomSet.has('body_ache')) {
      issues.push('Fever with allergy symptoms is unusual - allergies typically do not cause fever');
    }

    // Check for unrealistic patterns
    const severities = Object.values(input.severity);
    if (severities.length > 0) {
      const maxSeverity = Math.max(...severities);
      const minSeverity = Math.min(...severities);
      const avgSeverity = severities.reduce((a, b) => a + b, 0) / severities.length;
      
      if (maxSeverity > 9 && minSeverity < 2 && severities.length > 3) {
        issues.push('Unrealistic severity distribution detected');
      }

      // All symptoms at maximum
      if (severities.length > 5 && severities.every(s => s >= 9)) {
        impossible.push('All symptoms at maximum severity is medically unlikely');
      }
    }

    // Check duration vs symptoms
    if (input.duration > 168 && symptomSet.has('fever') && 
        (input.severity['fever'] || 0) > 7) {
      issues.push('High fever lasting more than a week requires medical attention');
    }

    // ========== Determine if logical ==========
    const logical = contradictions.length === 0 && impossible.length === 0 && 
                    symptomCount <= 20 && systemCount < 5;

    return {
      logical,
      issues,
      contradictions,
      impossible
    };
  }

  /**
   * Normalize LLM result to ensure proper structure
   */
  private normalizeResult(result: any): LLMValidationResult {
    return {
      logical: Boolean(result.logical ?? true),
      issues: Array.isArray(result.issues) ? result.issues : [],
      contradictions: Array.isArray(result.contradictions) ? result.contradictions : [],
      impossible: Array.isArray(result.impossible) ? result.impossible : []
    };
  }
}

