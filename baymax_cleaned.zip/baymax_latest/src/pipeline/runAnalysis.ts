import * as path from 'path';
import { UserSymptomInput, BaymaxHealthReport } from '../types';
import { ConsistencyCheckerModel } from '../ann/models/consistencyChecker';
import { DiseaseClassifierModel } from '../ann/models/diseaseClassifier';
import { RiskEngineModel } from '../ann/models/riskEngine';
import { MedicalRuleEngine } from '../rules/ruleEngine';
import { LLMValidator } from '../llm/validator';
import { AdviceGenerator } from '../llm/adviceGenerator';
import { symptomsToVector } from '../ann/preprocess';

export class HealthAnalysisPipeline {
  private consistencyChecker: ConsistencyCheckerModel;
  private diseaseModel: DiseaseClassifierModel;
  private riskModel: RiskEngineModel;
  private ruleEngine: MedicalRuleEngine;
  private llmValidator: LLMValidator;
  private adviceGenerator: AdviceGenerator;
  private modelsInitialized: boolean = false;

  constructor(useMockLLM: boolean = false) {
    this.consistencyChecker = new ConsistencyCheckerModel(52);
    this.diseaseModel = new DiseaseClassifierModel(52);
    this.riskModel = new RiskEngineModel(52);
    this.ruleEngine = new MedicalRuleEngine();
    this.llmValidator = new LLMValidator(useMockLLM);
    this.adviceGenerator = new AdviceGenerator(useMockLLM);
  }

  /**
   * Initialize all models (load from file if available)
   */
  async initialize(): Promise<void> {
    if (this.modelsInitialized) {
      return;
    }

    const modelsBasePath = path.join(__dirname, '..', 'models');
    
    try {
      await this.diseaseModel.loadModel(path.join(modelsBasePath, 'disease'));
      await this.riskModel.loadModel(path.join(modelsBasePath, 'risk'));
      await this.consistencyChecker.loadModel(path.join(modelsBasePath, 'consistency'));
      console.log('Loaded models from file');
    } catch (error) {
      console.log('Models not found, initializing new models');
      await this.diseaseModel.initialize();
      await this.riskModel.initialize();
      await this.consistencyChecker.initialize();
    }

    this.modelsInitialized = true;
  }

  /**
   * Main pipeline function - runs complete health analysis
   */
  async runHealthAnalysis(input: UserSymptomInput): Promise<BaymaxHealthReport> {
    try {
      // Initialize models if not already done
      await this.initialize();

      // Preprocess input
      const features = symptomsToVector(input);

      // Step 1: LLM Symptom Validator
      console.log('Step 1: Validating symptoms with LLM...');
      const llmChecks = await this.llmValidator.validateSymptoms(input);

      // Step 2: Consistency Checker ANN
      console.log('Step 2: Running consistency checker ANN...');
      const consistencyChecks = await this.consistencyChecker.checkConsistency(
        features,
        input.symptoms,
        input.severity
      );

      // Step 3: Main Disease ANN
      console.log('Step 3: Running disease prediction ANN...');
      const diseasePrediction = await this.diseaseModel.predict(features);

      // Step 4: Medical Rule Engine
      console.log('Step 4: Applying medical rules...');
      const ruleEngineOutput = this.ruleEngine.applyRules(input, diseasePrediction.probabilities);

      // Step 5: Risk Engine ANN
      console.log('Step 5: Running risk engine ANN...');
      const riskEngineOutput = await this.riskModel.predict(features);

      // Step 6: Merge everything and calculate meta information
      const warnings: string[] = [
        ...llmChecks.issues,
        ...llmChecks.contradictions,
        ...consistencyChecks.warnings,
        ...ruleEngineOutput.ruleWarnings
      ];

      // Calculate overall confidence
      const confidence = this.calculateConfidence(
        diseasePrediction.confidence,
        consistencyChecks.consistencyScore,
        llmChecks.logical
      );

      // Step 7: Generate final report structure
      const report: BaymaxHealthReport = {
        meta: {
          confidence: Math.round(confidence),
          warnings: [...new Set(warnings)] // Remove duplicates
        },
        ann: {
          diseaseProbabilities: ruleEngineOutput.corrected, // Use rule-corrected probabilities
          severity: diseasePrediction.severity,
          riskEngine: {
            riskLevel: riskEngineOutput.riskLevel,
            emergencyScore: riskEngineOutput.emergencyScore,
            progressionScore: riskEngineOutput.progressionScore
          }
        },
        ruleEngine: {
          corrected: ruleEngineOutput.corrected,
          ruleWarnings: ruleEngineOutput.ruleWarnings
        },
        validation: {
          llmChecks,
          consistencyChecks
        },
        finalAdvice: '' // Will be filled in next step
      };

      // Step 8: Generate natural language advice
      console.log('Step 6: Generating health advice...');
      report.finalAdvice = await this.adviceGenerator.generateAdvice(report);

      console.log('Analysis complete!');
      return report;
    } catch (error) {
      console.error('Error in health analysis pipeline:', error);
      throw new Error(`Health analysis failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Calculate overall confidence score
   */
  private calculateConfidence(
    diseaseConfidence: number,
    consistencyScore: number,
    llmLogical: boolean
  ): number {
    // Weighted average
    const consistencyWeight = 0.3;
    const diseaseWeight = 0.5;
    const llmWeight = 0.2;

    const llmScore = llmLogical ? 100 : 50;

    return (
      diseaseConfidence * diseaseWeight +
      consistencyScore * 100 * consistencyWeight +
      llmScore * llmWeight
    );
  }

}

/**
 * Convenience function to run health analysis
 */
export async function runHealthAnalysis(
  input: UserSymptomInput,
  useMockLLM: boolean = false
): Promise<BaymaxHealthReport> {
  const pipeline = new HealthAnalysisPipeline(useMockLLM);
  await pipeline.initialize();
  return pipeline.runHealthAnalysis(input);
}

