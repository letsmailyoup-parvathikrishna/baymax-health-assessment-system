import { Router, Request, Response } from 'express';
import { UserSymptomInput, BaymaxHealthReport } from '../types';
import { runHealthAnalysis } from '../pipeline/runAnalysis';

const router = Router();

/**
 * POST /api/advice
 * Analyze symptoms and return health report
 */
router.post('/advice', async (req: Request, res: Response) => {
  try {
    const input: UserSymptomInput = req.body;

    // Validate input
    if (!input.symptoms || !Array.isArray(input.symptoms) || input.symptoms.length === 0) {
      return res.status(400).json({
        error: 'Invalid input: symptoms array is required and must not be empty'
      });
    }

    if (!input.severity || typeof input.severity !== 'object') {
      return res.status(400).json({
        error: 'Invalid input: severity object is required'
      });
    }

    if (typeof input.duration !== 'number' || input.duration < 0) {
      return res.status(400).json({
        error: 'Invalid input: duration must be a non-negative number'
      });
    }

    // Use mock LLM if OPENAI_API_KEY is not set
    const useMockLLM = !process.env.OPENAI_API_KEY;

    // Run analysis
    const report: BaymaxHealthReport = await runHealthAnalysis(input, useMockLLM);

    res.json(report);
  } catch (error) {
    console.error('Error in /advice endpoint:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

/**
 * GET /api/health
 * Health check endpoint
 */
router.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    service: 'Baymax Health Advisor',
    timestamp: new Date().toISOString()
  });
});

export default router;

