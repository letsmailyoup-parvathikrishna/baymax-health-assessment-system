import { UserSymptomInput, DiseaseProbabilities, RuleEngineOutput } from '../types';
import { MEDICAL_RULES, SymptomRule } from './symptomRules';
import { normalizeProbabilities } from '../ann/preprocess';

export class MedicalRuleEngine {
  /**
   * Apply medical rules to correct disease probabilities
   */
  applyRules(
    input: UserSymptomInput,
    initialProbabilities: DiseaseProbabilities
  ): RuleEngineOutput {
    let corrected: DiseaseProbabilities = { ...initialProbabilities };
    const ruleWarnings: string[] = [];

    // Apply each rule that matches
    for (const rule of MEDICAL_RULES) {
      if (rule.condition(input.symptoms, input.severity)) {
        corrected = rule.action(corrected);
        
        if (rule.warning) {
          ruleWarnings.push(rule.warning);
        }
      }
    }

    // Normalize probabilities to sum to 1
    const probArray = Object.values(corrected);
    const normalized = normalizeProbabilities(probArray);
    
    const diseaseKeys = Object.keys(corrected) as Array<keyof DiseaseProbabilities>;
    const normalizedProbs: DiseaseProbabilities = {} as DiseaseProbabilities;
    
    diseaseKeys.forEach((key, index) => {
      normalizedProbs[key] = normalized[index];
    });

    // Cap impossible predictions
    const finalProbs = this.capImpossiblePredictions(normalizedProbs, input);

    return {
      corrected: finalProbs as unknown as Record<string, number>,
      ruleWarnings
    };
  }

  /**
   * Cap medically impossible predictions based on symptom presence
   */
  private capImpossiblePredictions(
    probs: DiseaseProbabilities,
    input: UserSymptomInput
  ): DiseaseProbabilities {
    const capped = { ...probs };
    const symptomSet = new Set(input.symptoms.map(s => s.toLowerCase()));

    // ========== UTI - Requires urinary symptoms ==========
    const hasUrinarySymptoms = symptomSet.has('burning_urination') || 
                                symptomSet.has('frequent_urination') ||
                                symptomSet.has('lower_abdominal_pain');
    if (!hasUrinarySymptoms) {
      capped.uti = Math.min(capped.uti, 0.05); // Very low if no urinary symptoms
    }

    // ========== Food Poisoning / Stomach Infection - Requires GI symptoms ==========
    const hasGISymptoms = symptomSet.has('nausea') || 
                          symptomSet.has('vomiting') || 
                          symptomSet.has('diarrhea') ||
                          symptomSet.has('stomach_pain') ||
                          symptomSet.has('abdominal_cramps') ||
                          symptomSet.has('stomach_cramps');
    if (!hasGISymptoms) {
      capped.food_poisoning = Math.min(capped.food_poisoning, 0.05);
      capped.stomach_infection = Math.min(capped.stomach_infection, 0.1);
    }

    // ========== Dehydration - Requires dehydration indicators ==========
    const hasDehydrationSigns = symptomSet.has('thirst') || 
                                 symptomSet.has('dry_mouth') || 
                                 symptomSet.has('dehydration_signs') ||
                                 (symptomSet.has('vomiting') && symptomSet.has('diarrhea'));
    if (!hasDehydrationSigns) {
      capped.dehydration = Math.min(capped.dehydration, 0.1);
    }

    // ========== Migraine - Fever makes it unlikely ==========
    if (symptomSet.has('fever')) {
      capped.migraine = Math.min(capped.migraine, 0.2); // Fever suggests infection, not migraine
    }

    // ========== Allergy - Fever makes it unlikely ==========
    if (symptomSet.has('fever') && symptomSet.has('body_ache')) {
      capped.allergy = Math.min(capped.allergy, 0.15); // Fever + body ache suggests infection
    }

    // ========== COVID - Loss of smell/taste is strong indicator ==========
    const hasLossOfSmellTaste = symptomSet.has('loss_of_smell') || symptomSet.has('loss_of_taste');
    if (hasLossOfSmellTaste && capped.covid < 0.3) {
      // If loss of smell/taste but COVID probability is low, boost it
      capped.covid = Math.min(1, capped.covid * 1.5);
    }

    // ========== Flu vs Cold differentiation ==========
    // Flu typically has fever + body ache, cold typically doesn't
    if (!symptomSet.has('fever') && !symptomSet.has('body_ache')) {
      capped.flu = Math.min(capped.flu, 0.3); // Low fever/body ache = unlikely flu
    }
    if (symptomSet.has('fever') && symptomSet.has('body_ache') && !symptomSet.has('runny_nose')) {
      capped.cold = Math.min(capped.cold, 0.2); // Fever + body ache without runny nose = unlikely cold
    }

    // ========== Anxiety - Requires psychological symptoms ==========
    const hasPsychologicalSymptoms = symptomSet.has('anxiety') || 
                                     symptomSet.has('rapid_heartbeat') ||
                                     symptomSet.has('irritability') ||
                                     symptomSet.has('restlessness') ||
                                     symptomSet.has('trembling');
    if (!hasPsychologicalSymptoms && !symptomSet.has('dizziness')) {
      capped.anxiety = Math.min(capped.anxiety, 0.15);
    }

    // Re-normalize after capping
    const probArray = Object.values(capped);
    const normalized = normalizeProbabilities(probArray);
    const diseaseKeys = Object.keys(capped) as Array<keyof DiseaseProbabilities>;
    const finalProbs: DiseaseProbabilities = {} as DiseaseProbabilities;
    
    diseaseKeys.forEach((key, index) => {
      finalProbs[key] = normalized[index];
    });

    return finalProbs;
  }

  /**
   * Get rule explanations for debugging
   */
  getMatchingRules(input: UserSymptomInput): SymptomRule[] {
    return MEDICAL_RULES.filter(rule => 
      rule.condition(input.symptoms, input.severity)
    );
  }
}

