import { DiseaseProbabilities } from '../types';

/**
 * Medical knowledge rules for symptom combinations
 */
export interface SymptomRule {
  condition: (symptoms: string[], severities: Record<string, number>) => boolean;
  action: (probs: DiseaseProbabilities) => DiseaseProbabilities;
  warning?: string;
}

export const MEDICAL_RULES: SymptomRule[] = [
  // ========== COVID-19 SPECIFIC RULES ==========
  {
    condition: (symptoms) =>
      symptoms.includes('loss_of_smell') || symptoms.includes('loss_of_taste'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.covid = Math.min(1, adjusted.covid * 2.5); // Strong COVID indicator
      adjusted.flu = Math.max(0, adjusted.flu * 0.6);
      adjusted.cold = Math.max(0, adjusted.cold * 0.5);
      return adjusted;
    },
    warning: 'Loss of smell/taste is a strong COVID-19 indicator'
  },
  {
    condition: (symptoms, severities) =>
      symptoms.includes('fever') && 
      symptoms.includes('cough') && 
      symptoms.includes('shortness_of_breath') &&
      (severities['fever'] || 0) > 6,
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.covid = Math.min(1, adjusted.covid * 2.0);
      adjusted.flu = Math.min(1, adjusted.flu * 1.2);
      adjusted.cold = Math.max(0, adjusted.cold * 0.4);
      return adjusted;
    }
  },

  // ========== FLU SPECIFIC RULES ==========
  {
    condition: (symptoms, severities) =>
      symptoms.includes('fever') && 
      symptoms.includes('body_ache') && 
      symptoms.includes('chills') &&
      (severities['fever'] || 0) > 6,
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.flu = Math.min(1, adjusted.flu * 2.2);
      adjusted.covid = Math.min(1, adjusted.covid * 1.3);
      adjusted.cold = Math.max(0, adjusted.cold * 0.5);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      symptoms.includes('fever') && 
      symptoms.includes('body_ache') && 
      symptoms.includes('fatigue') &&
      !symptoms.includes('runny_nose'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.flu = Math.min(1, adjusted.flu * 1.8);
      adjusted.cold = Math.max(0, adjusted.cold * 0.6);
      return adjusted;
    }
  },

  // ========== COMMON COLD SPECIFIC RULES ==========
  {
    condition: (symptoms) =>
      (symptoms.includes('runny_nose') || symptoms.includes('congestion')) &&
      symptoms.includes('sore_throat') &&
      !symptoms.includes('fever') &&
      !symptoms.includes('body_ache'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.cold = Math.min(1, adjusted.cold * 2.0);
      adjusted.flu = Math.max(0, adjusted.flu * 0.5);
      adjusted.covid = Math.max(0, adjusted.covid * 0.6);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      symptoms.includes('runny_nose') && 
      symptoms.includes('sneezing') &&
      !symptoms.includes('fever') &&
      !symptoms.includes('body_ache'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.cold = Math.min(1, adjusted.cold * 1.5);
      adjusted.allergy = Math.min(1, adjusted.allergy * 1.2);
      adjusted.flu = Math.max(0, adjusted.flu * 0.6);
      return adjusted;
    }
  },

  // ========== ALLERGY SPECIFIC RULES ==========
  {
    condition: (symptoms) =>
      symptoms.includes('sneezing') && 
      symptoms.includes('itchy_eyes') &&
      !symptoms.includes('fever'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.allergy = Math.min(1, adjusted.allergy * 2.5);
      adjusted.cold = Math.max(0, adjusted.cold * 0.5);
      adjusted.flu = Math.max(0, adjusted.flu * 0.4);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      (symptoms.includes('itchy_skin') || symptoms.includes('rash')) &&
      symptoms.includes('sneezing') &&
      !symptoms.includes('fever'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.allergy = Math.min(1, adjusted.allergy * 2.0);
      return adjusted;
    }
  },

  // ========== STOMACH INFECTION / FOOD POISONING RULES ==========
  {
    condition: (symptoms) =>
      symptoms.includes('nausea') && 
      symptoms.includes('vomiting') && 
      symptoms.includes('diarrhea') &&
      (symptoms.includes('stomach_pain') || symptoms.includes('abdominal_cramps')),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.food_poisoning = Math.min(1, adjusted.food_poisoning * 2.2);
      adjusted.stomach_infection = Math.min(1, adjusted.stomach_infection * 1.8);
      // Strongly reduce respiratory diseases
      adjusted.flu = Math.max(0, adjusted.flu * 0.3);
      adjusted.cold = Math.max(0, adjusted.cold * 0.3);
      adjusted.covid = Math.max(0, adjusted.covid * 0.4);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      (symptoms.includes('stomach_pain') || symptoms.includes('abdominal_cramps')) &&
      (symptoms.includes('nausea') || symptoms.includes('vomiting')) &&
      !symptoms.includes('fever'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.stomach_infection = Math.min(1, adjusted.stomach_infection * 1.6);
      adjusted.food_poisoning = Math.min(1, adjusted.food_poisoning * 1.4);
      adjusted.flu = Math.max(0, adjusted.flu * 0.6);
      adjusted.cold = Math.max(0, adjusted.cold * 0.6);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      symptoms.includes('vomiting') && 
      symptoms.includes('diarrhea') &&
      symptoms.includes('bloating'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.food_poisoning = Math.min(1, adjusted.food_poisoning * 1.8);
      adjusted.stomach_infection = Math.min(1, adjusted.stomach_infection * 1.5);
      return adjusted;
    }
  },

  // ========== UTI SPECIFIC RULES ==========
  {
    condition: (symptoms) =>
      symptoms.includes('burning_urination') && 
      symptoms.includes('frequent_urination'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.uti = Math.min(1, adjusted.uti * 3.0); // Very strong indicator
      // Strongly reduce unrelated diseases
      adjusted.flu = Math.max(0, adjusted.flu * 0.3);
      adjusted.cold = Math.max(0, adjusted.cold * 0.3);
      adjusted.covid = Math.max(0, adjusted.covid * 0.3);
      adjusted.stomach_infection = Math.max(0, adjusted.stomach_infection * 0.5);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      (symptoms.includes('burning_urination') || symptoms.includes('frequent_urination')) &&
      symptoms.includes('lower_abdominal_pain'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.uti = Math.min(1, adjusted.uti * 2.5);
      return adjusted;
    }
  },

  // ========== DEHYDRATION SPECIFIC RULES ==========
  {
    condition: (symptoms) =>
      (symptoms.includes('thirst') || symptoms.includes('dry_mouth')) &&
      symptoms.includes('fatigue') &&
      (symptoms.includes('vomiting') || symptoms.includes('diarrhea')),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.dehydration = Math.min(1, adjusted.dehydration * 2.5);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      symptoms.includes('thirst') && 
      symptoms.includes('dry_mouth') && 
      symptoms.includes('dizziness'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.dehydration = Math.min(1, adjusted.dehydration * 2.0);
      return adjusted;
    }
  },

  // ========== MIGRAINE SPECIFIC RULES ==========
  {
    condition: (symptoms) =>
      symptoms.includes('headache') &&
      (symptoms.includes('sensitivity_to_light') || symptoms.includes('nausea')) &&
      !symptoms.includes('fever') &&
      !symptoms.includes('cough') &&
      !symptoms.includes('runny_nose'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.migraine = Math.min(1, adjusted.migraine * 2.5);
      adjusted.flu = Math.max(0, adjusted.flu * 0.4);
      adjusted.cold = Math.max(0, adjusted.cold * 0.4);
      adjusted.covid = Math.max(0, adjusted.covid * 0.4);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      symptoms.includes('headache') &&
      !symptoms.includes('fever') &&
      !symptoms.includes('body_ache') &&
      !symptoms.includes('cough'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.migraine = Math.min(1, adjusted.migraine * 1.6);
      adjusted.anxiety = Math.min(1, adjusted.anxiety * 1.3);
      return adjusted;
    }
  },

  // ========== ANXIETY SPECIFIC RULES ==========
  {
    condition: (symptoms) =>
      symptoms.includes('anxiety') &&
      (symptoms.includes('rapid_heartbeat') || symptoms.includes('sweating')) &&
      (symptoms.includes('irritability') || symptoms.includes('restlessness')),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.anxiety = Math.min(1, adjusted.anxiety * 2.5);
      adjusted.migraine = Math.min(1, adjusted.migraine * 1.2);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      (symptoms.includes('rapid_heartbeat') || symptoms.includes('trembling')) &&
      symptoms.includes('dizziness') &&
      !symptoms.includes('fever') &&
      !symptoms.includes('chest_pain'),
    action: (probs) => {
      const adjusted = { ...probs };
      adjusted.anxiety = Math.min(1, adjusted.anxiety * 2.0);
      return adjusted;
    }
  },

  // ========== EXCLUSION RULES (Reduce impossible combinations) ==========
  {
    condition: (symptoms) =>
      symptoms.includes('burning_urination') &&
      (symptoms.includes('cough') || symptoms.includes('runny_nose')),
    action: (probs) => {
      // UTI symptoms with respiratory symptoms are unlikely
      const adjusted = { ...probs };
      adjusted.cold = Math.max(0, adjusted.cold * 0.4);
      adjusted.flu = Math.max(0, adjusted.flu * 0.4);
      adjusted.covid = Math.max(0, adjusted.covid * 0.4);
      return adjusted;
    }
  },
  {
    condition: (symptoms) =>
      (symptoms.includes('nausea') || symptoms.includes('vomiting') || symptoms.includes('diarrhea')) &&
      symptoms.includes('burning_urination'),
    action: (probs) => {
      // GI symptoms with UTI symptoms suggest separate conditions
      const adjusted = { ...probs };
      // Keep both but reduce each slightly
      adjusted.stomach_infection = Math.max(0, adjusted.stomach_infection * 0.8);
      adjusted.food_poisoning = Math.max(0, adjusted.food_poisoning * 0.8);
      adjusted.uti = Math.max(0, adjusted.uti * 0.8);
      return adjusted;
    },
    warning: 'Multiple symptom systems detected - may indicate multiple conditions'
  },

  // ========== CONTRADICTION DETECTION ==========
  {
    condition: (symptoms) =>
      symptoms.includes('diarrhea') && symptoms.includes('constipation'),
    action: (probs) => {
      // This is contradictory, reduce all probabilities
      const adjusted = { ...probs };
      Object.keys(adjusted).forEach(key => {
        adjusted[key as keyof DiseaseProbabilities] *= 0.4;
      });
      return adjusted;
    },
    warning: 'Contradictory symptoms detected - please verify input'
  }
];

