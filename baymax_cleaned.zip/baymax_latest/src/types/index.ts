export interface UserSymptomInput {
  symptoms: string[];
  severity: Record<string, number>; // symptom -> severity (0-10)
  duration: number; // hours
  age?: number;
  gender?: string;
  existingConditions?: string[];
}

export interface ConsistencyCheckResult {
  consistencyScore: number;
  warnings: string[];
  isManipulated: boolean;
}

export interface DiseaseProbabilities {
  flu: number;
  cold: number;
  covid: number;
  allergy: number;
  migraine: number;
  stomach_infection: number;
  uti: number;
  dehydration: number;
  anxiety: number;
  food_poisoning: number;
}

export interface RiskEngineOutput {
  riskLevel: "low" | "medium" | "high";
  emergencyScore: number;
  progressionScore: number;
}

export interface RuleEngineOutput {
  corrected: Record<string, number>;
  ruleWarnings: string[];
}

export interface LLMValidationResult {
  logical: boolean;
  issues: string[];
  contradictions: string[];
  impossible: string[];
}

export interface BaymaxHealthReport {
  meta: {
    confidence: number;
    warnings: string[];
  };
  ann: {
    diseaseProbabilities: Record<string, number>;
    severity: number;
    riskEngine: {
      riskLevel: string;
      emergencyScore: number;
      progressionScore: number;
    };
  };
  ruleEngine: {
    corrected: Record<string, number>;
    ruleWarnings: string[];
  };
  validation: {
    llmChecks: LLMValidationResult;
    consistencyChecks: ConsistencyCheckResult;
  };
  finalAdvice: string;
}

