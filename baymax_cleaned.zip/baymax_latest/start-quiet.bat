@echo off
echo Starting Baymax Health Advisor...

REM Navigate to project root
cd /d "%~dp0"

REM Start backend in background
echo Starting backend...
start /B npm run dev > backend.log 2>&1

REM Wait for backend to initialize
timeout /t 3 /nobreak >nul

REM Start frontend in background
echo Starting frontend...
cd frontend
start /B npm run dev > ..\frontend.log 2>&1
cd ..

echo.
echo Services started in background!
echo Backend:  http://localhost:3000
echo Frontend: http://localhost:5173
echo.
echo Logs: backend.log and frontend.log
echo.
pause

