@echo off
echo ========================================
echo   Baymax Health Advisor - Starting...
echo ========================================
echo.

REM Check if Node.js is installed
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Node.js is not installed or not in PATH
    pause
    exit /b 1
)

REM Navigate to project root
cd /d "%~dp0"

echo [1/3] Installing backend dependencies...
if not exist "node_modules" (
    call npm install
)

echo.
echo [2/3] Starting backend server...
start "Baymax Backend" cmd /k "npm run dev"

REM Wait a bit for backend to start
timeout /t 3 /nobreak >nul

echo.
echo [3/3] Starting frontend server...
cd frontend
if not exist "node_modules" (
    echo Installing frontend dependencies...
    call npm install
)
start "Baymax Frontend" cmd /k "npm run dev"

echo.
echo ========================================
echo   All services started!
echo ========================================
echo.
echo Backend:  http://localhost:3000
echo Frontend: http://localhost:5173
echo.
echo Press any key to exit this window...
echo (The servers will continue running in their own windows)
pause >nul

