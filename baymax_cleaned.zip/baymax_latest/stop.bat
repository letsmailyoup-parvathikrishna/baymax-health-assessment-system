@echo off
echo Stopping Baymax Health Advisor services...

REM Kill Node processes (backend and frontend)
taskkill /F /IM node.exe >nul 2>&1

echo All services stopped.
timeout /t 2 /nobreak >nul

